# Fixed admission-recheck calibration protocol

The six serial arms are native-before, BF0, pool1600-off, pool1600-recheck, pool1600-recheck-repeat and native-after. All use the original calibration16×32 inputs/reference,ctx4096/cache64/chunk512 and exact earlier one-slot guards GAP.30, mass.20, total.35, rank48. Only POOL_NATIVE_RECHECK0 versus1 changes between the pool controls; READY age1600, queueTTL80, late1,400MiB ownership and all other gates are fixed. No held-out case or outcome is used for selection or tuning. Frozenf4 runtime is independently reviewed; no defaults are promoted.

The frozen literal065 fixture frontend is already linked against the separatef4 objects. Full512 unmodified candidate float rows and metadata are retained. Native-before/after must match the complete prior SHA1993aa5f… plus512 bit-equal rows and zero raw scalar deltas. BF0 must match prior fullSHAceb6df37…. Native demand counters must equal the earlier67908 preads/225302446080 requested=returned bytes/191684 hits/22636 misses/16500 evictions. BF0 must equal59277 preads/196666859520 bytes/194561 hits/19759 misses/13623 evictions. Failed controls stop dependent arms and preserve every return code. Pool approximate repeats may differ and are measured without an equality requirement.

Every arm enables final PROBE_IO. Exact logical demand reads plus all global and pooled background read/teardown bytes are summed once; cache_loader_bytes are not added again. Recheck not_started_bytes is a separate unstarted logical request observation, not a credit against actual requested/returned bytes and not a physical SSD traffic estimate. Queue conservation adds queue_native_resident_drops as a disjoint term. All prior completed/READY/expiry/age/queue/worker/allocation/fd/cap/late-install balances remain strict; foreign owner attempts or failed reads/installations reject the run. Quality summaries retain all16 prompt means, paired2000-resample bootstrap with seed20261002, tail KL and argmax flips. Timings are diagnostic only.

Preparation reads only the16-byte old raw header/size and copied input hashes; it never opens a model, initializes Metal, reads model metadata, hashes/copies the full raw reference or inspects text for policy selection. The full reference SHA and model stat are first verified under the exact prepared MAIN pressure-guard parent and held lock. Manifest SHA is explicit in prepared argv and exact parent suffix; the pinned framework interpreter and complete64-file input/helper/shader inventory are checked before model stat. All inherited names starting with literalDS4 are removed. No automatic retry or second job is launched. Separate ROOT model grant is required.

Seventy-five model-free CPU trials cover all old parser/lifetime/balance checks, large uint counter handling, the new queue-removal/byte classification, duplicate/missing/incompatible recheck footers, exact old raw+IO controls, fixed policy identity, manifest+command tampering with an old argv digest, parent aliases/suffix/interpreter/lock failures and omitted/foreign input/shader paths. Source, objects, helpers, command, manifest, input hashes and proof are frozen before any grant. Test source and captured JSON result digests have distinct explicit labels.
# Corrective study child

The unrun `1a814051` source/plan remains frozen. This child pins `/bin/ps`
with a two-second lookup bound and validates exactly 512 finite CSV rows before
any summary/bootstrap: 16 frozen case identities, steps 0..31 in raw record
order, and exact target/prompt-token keys against the pinned raw metadata.
Runtime, helper binary, policies, input set, shaders and old controls are
unchanged. Raw completeness and CSV completeness are asserted separately.
