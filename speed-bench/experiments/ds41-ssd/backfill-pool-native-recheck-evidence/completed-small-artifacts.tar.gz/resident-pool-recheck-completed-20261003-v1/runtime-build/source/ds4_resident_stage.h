#ifndef DS4_RESIDENT_STAGE_H
#define DS4_RESIDENT_STAGE_H

/* Private CPU-only staging ownership. All public helpers are owner-thread
 * calls; the worker reads immutable identity/fd/bytes and publishes status.
 * No mapped model reads, cache access, Metal API, or shared pread-pool wait. */
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#ifdef __APPLE__
#include <pthread/qos.h>
#endif

enum { DS4_STAGE_IDLE, DS4_STAGE_READING, DS4_STAGE_READY, DS4_STAGE_FAILED };
typedef struct {
    const void *model_map;
    uint64_t model_size;
    uint32_t layer, expert;
    uint64_t generation;
    uint32_t quant_types[3];
    uint64_t offsets[3], lengths[3];
} ds4_resident_stage_identity;

typedef struct {
    uint64_t attempts, started, busy_skips, ready_skips, completed, failed;
    uint64_t consumed, expired, resets, pread_calls, requested_bytes, returned_bytes;
    uint64_t copied_bytes, peak_bytes;
} ds4_resident_stage_counters;

typedef struct {
    ds4_resident_stage_identity identity;
    ds4_resident_stage_counters counters;
    uint8_t *bytes;
    uint64_t size, step, start_step;
    int fd, state, thread_started;
    pthread_t thread;
} ds4_resident_stage;

static inline int ds4_resident_stage_status(const ds4_resident_stage *s) {
    return __atomic_load_n(&s->state, __ATOMIC_ACQUIRE);
}

static inline int ds4_resident_stage_matches(const ds4_resident_stage *s,
        const ds4_resident_stage_identity *id) {
    if (!id || ds4_resident_stage_status(s) != DS4_STAGE_READY) return 0;
    return s->identity.model_map == id->model_map &&
        s->identity.model_size == id->model_size && s->identity.layer == id->layer &&
        s->identity.expert == id->expert &&
        s->identity.generation == id->generation &&
        !memcmp(s->identity.quant_types, id->quant_types, sizeof(id->quant_types)) &&
        !memcmp(s->identity.offsets, id->offsets, sizeof(id->offsets)) &&
        !memcmp(s->identity.lengths, id->lengths, sizeof(id->lengths));
}

static void *ds4_resident_stage_worker(void *opaque) {
    ds4_resident_stage *s = opaque;
#ifdef DS4_RESIDENT_STAGE_TEST_BEFORE_READ
    DS4_RESIDENT_STAGE_TEST_BEFORE_READ(s);
#endif
#ifdef __APPLE__
    (void)pthread_set_qos_class_self_np(QOS_CLASS_BACKGROUND, 0);
#endif
    uint64_t base = 0;
    int ok = 1;
    for (uint32_t tensor = 0; tensor < 3 && ok; tensor++) {
        uint64_t pos = 0, len = s->identity.lengths[tensor];
        while (pos < len) {
            const uint64_t remain = len - pos;
            const size_t want = remain > (uint64_t)SSIZE_MAX ? (size_t)SSIZE_MAX : (size_t)remain;
            __atomic_fetch_add(&s->counters.pread_calls, 1, __ATOMIC_RELAXED);
            __atomic_fetch_add(&s->counters.requested_bytes, want, __ATOMIC_RELAXED);
            const ssize_t n = pread(s->fd, s->bytes + base + pos, want,
                (off_t)(s->identity.offsets[tensor] + pos));
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) { ok = 0; break; }
            __atomic_fetch_add(&s->counters.returned_bytes, (uint64_t)n, __ATOMIC_RELAXED);
            pos += (uint64_t)n;
        }
        base += len;
    }
    (void)close(s->fd);
    __atomic_fetch_add(ok ? &s->counters.completed : &s->counters.failed, 1, __ATOMIC_RELAXED);
    /* Last access to ownership/status. Owner can now join without waiting on
     * I/O, copy/release bytes, or discard; busy resets still join this worker. */
    __atomic_store_n(&s->state, ok ? DS4_STAGE_READY : DS4_STAGE_FAILED, __ATOMIC_RELEASE);
    return NULL;
}

static inline void ds4_resident_stage_release(ds4_resident_stage *s) {
    if (s->thread_started) (void)pthread_join(s->thread, NULL);
    s->thread_started = 0;
    free(s->bytes);
    s->bytes = NULL;
    s->size = 0;
    s->fd = -1;
    memset(&s->identity, 0, sizeof(s->identity));
    __atomic_store_n(&s->state, DS4_STAGE_IDLE, __ATOMIC_RELEASE);
}

static inline void ds4_resident_stage_reset(ds4_resident_stage *s) {
    if (s->thread_started || s->bytes)
        __atomic_fetch_add(&s->counters.resets, 1, __ATOMIC_RELAXED);
    ds4_resident_stage_release(s);
}

static inline void ds4_resident_stage_tick(ds4_resident_stage *s, uint64_t max_age) {
    s->step++;
    const int state = ds4_resident_stage_status(s);
    if (state == DS4_STAGE_FAILED ||
        (state == DS4_STAGE_READY && s->step - s->start_step > max_age)) {
        if (state == DS4_STAGE_READY)
            __atomic_fetch_add(&s->counters.expired, 1, __ATOMIC_RELAXED);
        ds4_resident_stage_release(s);
    }
}

static inline int ds4_resident_stage_request(ds4_resident_stage *s, int source_fd,
        const ds4_resident_stage_identity *id, uint64_t budget) {
    __atomic_fetch_add(&s->counters.attempts, 1, __ATOMIC_RELAXED);
    const int status = ds4_resident_stage_status(s);
    if (status == DS4_STAGE_READING) {
        __atomic_fetch_add(&s->counters.busy_skips, 1, __ATOMIC_RELAXED); return 0;
    }
    if (status == DS4_STAGE_READY) {
        __atomic_fetch_add(&s->counters.ready_skips, 1, __ATOMIC_RELAXED); return 0;
    }
    if (status == DS4_STAGE_FAILED) ds4_resident_stage_release(s);
    if (!id || source_fd < 0 || !id->model_map || !budget) return 0;
    uint64_t bytes = 0;
    for (uint32_t i = 0; i < 3; i++) {
        if (!id->lengths[i] || id->offsets[i] > id->model_size ||
            id->lengths[i] > id->model_size - id->offsets[i] ||
            id->offsets[i] > (uint64_t)LLONG_MAX ||
            id->lengths[i] > (uint64_t)LLONG_MAX - id->offsets[i] ||
            id->lengths[i] > budget - bytes) return 0;
        bytes += id->lengths[i];
    }
    if (bytes > SIZE_MAX) return 0;
    int fd = dup(source_fd);
    if (fd < 0) return 0;
    if (fcntl(fd, F_SETFD, FD_CLOEXEC) < 0) { close(fd); return 0; }
    uint8_t *data = malloc((size_t)bytes);
    if (!data) { close(fd); return 0; }
    s->identity = *id; s->fd = fd; s->bytes = data; s->size = bytes;
    s->start_step = s->step;
    __atomic_store_n(&s->state, DS4_STAGE_READING, __ATOMIC_RELEASE);
    if (pthread_create(&s->thread, NULL, ds4_resident_stage_worker, s) != 0) {
        close(fd); free(data); s->bytes = NULL; s->size = 0; s->fd = -1;
        __atomic_store_n(&s->state, DS4_STAGE_IDLE, __ATOMIC_RELEASE);
        return 0;
    }
    s->thread_started = 1;
    __atomic_fetch_add(&s->counters.started, 1, __ATOMIC_RELAXED);
    if (bytes > s->counters.peak_bytes) s->counters.peak_bytes = bytes;
    return 1;
}

/* On a READY exact native demand, copy into existing protected load buffers.
 * This is a one-shot CPU source; cache install/GPU binding remain the loader's. */
static inline int ds4_resident_stage_copy(ds4_resident_stage *s,
        const ds4_resident_stage_identity *id, uint8_t *dest[3]) {
    if (!dest || !dest[0] || !dest[1] || !dest[2] ||
        !ds4_resident_stage_matches(s, id)) return 0;
    if (s->thread_started) { (void)pthread_join(s->thread, NULL); s->thread_started = 0; }
    uint64_t at = 0;
    for (uint32_t i = 0; i < 3; i++) {
        memcpy(dest[i], s->bytes + at, (size_t)id->lengths[i]); at += id->lengths[i];
    }
    __atomic_fetch_add(&s->counters.consumed, 1, __ATOMIC_RELAXED);
    __atomic_fetch_add(&s->counters.copied_bytes, at, __ATOMIC_RELAXED);
    ds4_resident_stage_release(s);
    return 1;
}

#endif
