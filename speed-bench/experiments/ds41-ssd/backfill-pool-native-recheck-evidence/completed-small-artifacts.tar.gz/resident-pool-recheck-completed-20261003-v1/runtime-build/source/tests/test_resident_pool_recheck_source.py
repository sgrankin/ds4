"""Default dispatch/ABI/native source proof against frozen f6ffce9."""
from pathlib import Path
import hashlib,json,re,sys
root=Path(__file__).resolve().parents[1];base=Path(sys.argv[1])
def body(text,name):
    match=re.search(r'(?m)^[^\n;{}]*\b'+re.escape(name)+r'\([^;{}]*\)\s*\{',text);assert match,name
    start=text.index('{',match.start());at=start+1;depth=1
    while depth:depth+=(text[at]=='{')-(text[at]=='}');at+=1
    return text[start:at]
old=(base/'ds4_resident_pool.h').read_text();new=(root/'ds4_resident_pool.h').read_text()
assert body(old,'ds4_pool_kick')==body(new,'ds4_pool_kick_legacy')
for name in ['ds4_pool_worker','ds4_pool_poll','ds4_pool_expire','ds4_pool_tick','ds4_pool_ready','ds4_pool_request','ds4_pool_copy','ds4_pool_set_ready_age']:
    assert body(old,name)==body(new,name),name
reset=body(new,'ds4_pool_reset').replace('    p->native_recheck=NULL;p->native_recheck_context=NULL;\n','').replace('    memset(&p->native_recheck_owner,0,sizeof(p->native_recheck_owner));\n','')
assert reset==body(old,'ds4_pool_reset')
assert 'if (!p->native_recheck) return ds4_pool_kick_legacy(p,current);' in body(new,'ds4_pool_kick')
for name in ['ds4_gpu_stream_expert_backfill_pool_enable','ds4_gpu_stream_expert_backfill_pool_enable_ready_age','ds4_gpu_stream_expert_backfill_pool_metrics_read']:
    assert body((base/'ds4_metal.m').read_text(),name)==body((root/'ds4_metal.m').read_text(),name),name
# Existing declarations/structs are untouched; new APIs are inserted after the
# old pool metrics_read declaration. Demand and old pool ABI stay identical.
old=(base/'ds4_gpu.h').read_text();new=(root/'ds4_gpu.h').read_text()
insert=new[new.index('/* Separate opt-in metrics API;'):new.index('/* Diagnostic snapshot only:',new.index('/* Separate opt-in metrics API;'))]
assert new.replace(insert,'')==old
print(json.dumps(dict(default_kick_body_literal=True,worker_harvest_queue_ready_copy_unchanged=True,reset_only_clears_new_callback_owner=True,old_pool_setup_snapshot_and_gpu_header_abi_unchanged=True,model_parity_pending=True)))
