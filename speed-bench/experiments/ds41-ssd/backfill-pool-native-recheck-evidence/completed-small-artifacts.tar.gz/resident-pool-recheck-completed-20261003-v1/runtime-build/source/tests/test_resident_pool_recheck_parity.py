"""Model-free default80 differential test against the frozenf6ffce9 real-reader header."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path(__file__).resolve().parents[1]
base=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
source=(base/'ds4_resident_pool.h').read_bytes()
assert hashlib.sha256(source).hexdigest()=='ff09f1df0feef546cafc7d68248a8542528dd22fcef5de9caac81e0634c4cf48'
old=re.sub(r'\b(ds4_pool\w*|ds4_resident_pool\w*|DS4_POOL\w*|DS4_RESIDENT_POOL\w*)\b',lambda m:'old_'+m[0] if m[0][0].islower() else 'OLD_'+m[0],source.decode())
(out/'old_pool.h').write_text(old)
test=r'''
#include <assert.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
static int held,entered;
static void pause_reader(void *p) {
 (void)p;__atomic_fetch_add(&entered,1,__ATOMIC_RELEASE);
 while(__atomic_load_n(&held,__ATOMIC_ACQUIRE)) {struct timespec t={0,1000000};nanosleep(&t,0);}
}
#define OLD_DS4_RESIDENT_POOL_TEST_BEFORE_READ pause_reader
#include "old_pool.h"
#define DS4_RESIDENT_POOL_TEST_BEFORE_READ pause_reader
#include "ds4_resident_pool.h"
static unsigned char bytes[4096];
static void check(old_ds4_resident_pool *a,ds4_resident_pool *b) {
#define CMP(n) assert(__atomic_load_n(&a->counters.n,__ATOMIC_RELAXED)==__atomic_load_n(&b->counters.n,__ATOMIC_RELAXED));
 OLD_DS4_POOL_COUNTERS(CMP)
#undef CMP
 assert(a->step==b->step && a->payload_live==b->payload_live && a->payload_peak==b->payload_peak);
 assert(a->ready_count==b->ready_count && a->queue_count==b->queue_count && a->sequence==b->sequence);
 assert(old_ds4_pool_state(a)==ds4_pool_state(b));
 for(unsigned i=0;i<40;i++) {
  assert(!!a->ready[i].bytes==!!b->ready[i].bytes && a->queue[i].valid==b->queue[i].valid);
  assert(a->latest_valid[i]==b->latest_valid[i]);
  if(a->latest_valid[i]) assert(ds4_resident_stage_identity_equal(&a->latest[i],&b->latest[i]));
  if(a->ready[i].bytes) {assert(ds4_resident_stage_identity_equal(&a->ready[i].id,&b->ready[i].id));assert(!memcmp(a->ready[i].bytes,b->ready[i].bytes,a->ready[i].size));}
  if(a->queue[i].valid) assert(ds4_resident_stage_identity_equal(&a->queue[i].id,&b->queue[i].id));
 }
}
static void finish_pair(old_ds4_resident_pool *a,ds4_resident_pool *b) {
 for(int i=0;i<5000;i++) {
  int x=old_ds4_pool_state(a),y=ds4_pool_state(b);
  if((x==OLD_DS4_POOL_READY || x==OLD_DS4_POOL_FAILED) && (y==DS4_POOL_READY || y==DS4_POOL_FAILED)) {
   old_ds4_pool_poll(a);ds4_pool_poll(b);check(a,b);return;
  }
  struct timespec t={0,1000000};nanosleep(&t,0);
 }assert(0);
}
static void wait_pair(void) {for(int i=0;i<5000;i++){if(__atomic_load_n(&entered,__ATOMIC_ACQUIRE)==2)return;struct timespec t={0,1000000};nanosleep(&t,0);}assert(0);}
static void hold_pair(void){__atomic_store_n(&entered,0,__ATOMIC_RELEASE);__atomic_store_n(&held,1,__ATOMIC_RELEASE);}
static void tick_pair(old_ds4_resident_pool *a,ds4_resident_pool *b,int n){for(int i=0;i<n;i++){old_ds4_pool_tick(a);ds4_pool_tick(b);}check(a,b);}
static void copy_pair(old_ds4_resident_pool *a,ds4_resident_pool *b,ds4_resident_stage_identity *id,int late){
 unsigned char x[96],y[96];unsigned char *xd[3]={x,x+32,x+64},*yd[3]={y,y+32,y+64};
 assert(old_ds4_pool_copy(a,id,xd,late)==ds4_pool_copy(b,id,yd,late));assert(!memcmp(x,y,96));check(a,b);
}
static void run(int explicit80,int fd) {
 old_ds4_resident_pool a={0};ds4_resident_pool b={0};
 assert(old_ds4_pool_init(&a,2*1024*1024) && ds4_pool_init(&b,2*1024*1024));
 if(explicit80)assert(ds4_pool_set_ready_age(&b,80));
 ds4_resident_stage_identity x={.model_map=bytes,.model_size=sizeof(bytes),.layer=2,.expert=1,.generation=17,.quant_types={22,22,8},.offsets={0,32,64},.lengths={32,32,32}},y=x,q=x;
 y.expert=2;q.layer=3;
 hold_pair();assert(old_ds4_pool_request(&a,fd,&x) && ds4_pool_request(&b,fd,&x));wait_pair();check(&a,&b);
 assert(old_ds4_pool_request(&a,fd,&q) && ds4_pool_request(&b,fd,&q));tick_pair(&a,&b,81);
 __atomic_store_n(&held,0,__ATOMIC_RELEASE);finish_pair(&a,&b);
 assert(old_ds4_pool_request(&a,fd,&x) && ds4_pool_request(&b,fd,&x));finish_pair(&a,&b);
 tick_pair(&a,&b,80);copy_pair(&a,&b,&x,0);
 assert(old_ds4_pool_request(&a,fd,&x) && ds4_pool_request(&b,fd,&x));finish_pair(&a,&b);tick_pair(&a,&b,81);
 assert(old_ds4_pool_request(&a,fd,&x) && ds4_pool_request(&b,fd,&x));finish_pair(&a,&b);tick_pair(&a,&b,15);
 hold_pair();assert(old_ds4_pool_request(&a,fd,&y) && ds4_pool_request(&b,fd,&y));wait_pair();
 assert(old_ds4_pool_request(&a,fd,&x) && ds4_pool_request(&b,fd,&x));
 assert(old_ds4_pool_request(&a,fd,&y) && ds4_pool_request(&b,fd,&y));check(&a,&b);
 __atomic_store_n(&held,0,__ATOMIC_RELEASE);finish_pair(&a,&b);copy_pair(&a,&b,&y,1);
 old_ds4_pool_reset(&a);ds4_pool_reset(&b);check(&a,&b);
 assert(b.counters.ready_expired==b.counters.completion_harvest_expired+b.counters.stored_ready_expired);
 assert(!b.counters.consumed_future_older80 && !b.counters.consumed_late_older80);
}
int main(void){for(unsigned i=0;i<sizeof(bytes);i++)bytes[i]=(unsigned char)i;
 char path[]="speed-bench/ideas/artifacts/resident-pool-cpu/parity-XXXXXX";
 int fd=mkstemp(path);assert(fd>=0);unlink(path);assert(write(fd,bytes,sizeof(bytes))==sizeof(bytes));
 run(0,fd);run(1,fd);close(fd);puts("PASS: frozenf6ffce9 vs implicit/explicit80 real-file reader, queue/completion/READY expiry, boundary copy, ABA replacement, inventories and every legacy counter");}
'''
# The shared stage equality helper has a different name across historical variants;
# both identities have the same type, so use the current pool's exact comparator.
test=test.replace('ds4_resident_stage_identity_equal','ds4_pool_identity_equal')
(out/'parity.c').write_text(test)
cmd=['cc','-O3','-ffast-math','-mcpu=native','-Wall','-Wextra','-std=c11','-pthread','-I',str(out),'-I',str(root),str(out/'parity.c'),'-o',str(out/'parity')]
subprocess.run(cmd,check=True);subprocess.run([str(out/'parity')],cwd=root,check=True)
print(json.dumps({'parent_header_sha256':hashlib.sha256(source).hexdigest(),'command':cmd,'model_opened':False,'gpu_initialized':False}))
