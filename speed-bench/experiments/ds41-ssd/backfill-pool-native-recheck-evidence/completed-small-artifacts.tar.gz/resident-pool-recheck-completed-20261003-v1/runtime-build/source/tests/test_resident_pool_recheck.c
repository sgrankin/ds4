/* Real file/reader queue tests. No model, Metal, mapped source dereference or
 * worker cache access. Admission uses only an owner callback with exact IDs. */
#include <assert.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
static int held,entered;
static void pause_reader(void *p) {
    (void)p;__atomic_fetch_add(&entered,1,__ATOMIC_RELEASE);
    while (__atomic_load_n(&held,__ATOMIC_ACQUIRE)) { struct timespec t={0,1000000};nanosleep(&t,NULL); }
}
#define DS4_RESIDENT_POOL_TEST_BEFORE_READ pause_reader
#include "../ds4_resident_pool.h"
#include "../ds4_resident_pool_gate.h"
static unsigned char source[4096];
static ds4_resident_stage_identity resident[40];
static unsigned valid[40],callbacks;
static pthread_t owner;
static int recheck(void *context,const ds4_resident_stage_identity *id) {
    assert(context==valid && pthread_equal(owner,pthread_self()));callbacks++;
    return valid[id->layer] && ds4_pool_identity_equal(id,&resident[id->layer]);
}
static int other_recheck(void *context,const ds4_resident_stage_identity *id) { (void)context;(void)id;return 0; }
static ds4_resident_stage_identity identity(unsigned layer,unsigned expert) {
    return (ds4_resident_stage_identity){.model_map=source,.model_size=sizeof(source),.layer=layer,.expert=expert,
        .generation=17,.quant_types={22,22,8},.offsets={0,32,64},.lengths={32,32,32}};
}
static void wait_entered(void) {
    for (int i=0;i<5000;i++) { if (__atomic_load_n(&entered,__ATOMIC_ACQUIRE)) return;struct timespec t={0,1000000};nanosleep(&t,NULL); } assert(0);
}
static void finish(ds4_resident_pool *p) {
    for (int i=0;i<5000;i++) { int s=ds4_pool_state(p);if(s==DS4_POOL_READY || s==DS4_POOL_FAILED){ds4_pool_poll(p);return;}struct timespec t={0,1000000};nanosleep(&t,NULL); } assert(0);
}
static void balance(ds4_resident_pool *p) {
    assert(p->counters.queued==p->counters.admissions+p->counters.queue_expired+p->counters.queue_ready_drops+
        p->counters.queue_reading_drops+p->counters.reset_queue_discards+p->recheck_counters.queue_native_resident_drops+p->queue_count);
    assert(p->counters.allocations==p->counters.frees && p->counters.allocated_bytes==p->counters.freed_bytes);
    assert(p->counters.dup_opens==p->counters.dup_closes && !p->payload_live && !p->queue_count && !p->ready_count);
    assert(p->owned_peak<=p->limit && !p->native_recheck && !p->worker);
}
static void queued_change(int fd,int mismatch) {
    memset(valid,0,sizeof(valid));callbacks=0;owner=pthread_self();
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,DS4_RESIDENT_POOL_LIMIT));
    assert(p.metadata_bytes==16384);assert(ds4_pool_set_native_recheck(&p,recheck,valid));
    ds4_resident_stage_identity a=identity(0,1),b=identity(1,2);
    __atomic_store_n(&held,1,__ATOMIC_RELEASE);__atomic_store_n(&entered,0,__ATOMIC_RELEASE);
    assert(ds4_pool_request(&p,fd,&a));wait_entered();assert(ds4_pool_request(&p,fd,&b));
    assert(p.queue[1].valid && p.queue_count==1);
    assert(!ds4_pool_set_native_recheck(&p,other_recheck,valid));
    resident[1]=b;valid[1]=1;
    if(mismatch==1) resident[1].offsets[0]++;
    if(mismatch==2) resident[1].generation++;
    if(mismatch==3) resident[1].quant_types[0]++;
    __atomic_store_n(&held,0,__ATOMIC_RELEASE);finish(&p);
    unsigned before=callbacks;int started=ds4_pool_kick(&p,1);assert(callbacks==before+1);
    assert(p.latest_valid[1] && ds4_pool_identity_equal(&p.latest[1],&b));
    if(!mismatch) {
        assert(!started && p.recheck_counters.queue_native_resident_drops==1 && p.recheck_counters.not_started_bytes==96);
        assert(p.counters.admissions==1 && p.counters.allocations==1 && p.counters.dup_opens==1 && p.counters.requested_bytes==96);
    } else {
        assert(started && !p.recheck_counters.queue_native_resident_drops);finish(&p);
        assert(p.counters.admissions==2 && p.counters.requested_bytes==192);
        unsigned char out[96],*dest[3]={out,out+32,out+64};assert(ds4_pool_copy(&p,&b,dest,0));assert(!memcmp(out,source,96));
    }
    unsigned counts=callbacks;ds4_resident_stage_identity bad=b;bad.generation++;
    assert(!ds4_pool_request(&p,fd,&bad));assert(callbacks==counts && ds4_pool_identity_equal(&p.latest[1],&b));
    ds4_pool_reset(&p);balance(&p);assert(ds4_pool_set_native_recheck(&p,other_recheck,NULL));ds4_pool_reset(&p);
}
static void bounded_queue(int fd) {
    memset(valid,0,sizeof(valid));callbacks=0;owner=pthread_self();ds4_resident_pool p={0};
    assert(ds4_pool_init(&p,DS4_RESIDENT_POOL_LIMIT) && ds4_pool_set_native_recheck(&p,recheck,valid));
    ds4_resident_stage_identity first=identity(39,0);
    __atomic_store_n(&held,1,__ATOMIC_RELEASE);__atomic_store_n(&entered,0,__ATOMIC_RELEASE);
    assert(ds4_pool_request(&p,fd,&first));wait_entered();
    for(unsigned i=0;i<40;i++) { resident[i]=identity(i,1);assert(ds4_pool_request(&p,fd,&resident[i])); }
    assert(p.queue_count==40);memset(valid,1,sizeof(valid));
    __atomic_store_n(&held,0,__ATOMIC_RELEASE);finish(&p);unsigned before=callbacks;
    assert(!ds4_pool_kick(&p,39));assert(callbacks==before+40 && !p.queue_count);
    assert(p.recheck_counters.queue_native_resident_drops==40 && p.recheck_counters.not_started_bytes==40*96);
    assert(p.counters.admissions==1 && p.counters.read_started==1 && p.counters.ready_superseded==1);
    ds4_pool_reset(&p);balance(&p);
}
static void *foreign(void *arg) { assert(!ds4_pool_kick(arg,0));return NULL; }
static void foreign_owner(void) {
    ds4_resident_pool p={0};owner=pthread_self();assert(ds4_pool_init(&p,DS4_RESIDENT_POOL_LIMIT));
    assert(ds4_pool_set_native_recheck(&p,recheck,valid));unsigned before=callbacks;
    pthread_t t;assert(!pthread_create(&t,NULL,foreign,&p));assert(!pthread_join(t,NULL));
    assert(p.recheck_counters.owner_rejections==1 && callbacks==before && !p.worker && !p.counters.admissions);
    ds4_pool_reset(&p);balance(&p);
}
int main(void) {
    int parsed=-1;
    assert(ds4_resident_pool_native_recheck_parse(NULL,&parsed)&&!parsed);
    assert(ds4_resident_pool_native_recheck_parse("",&parsed)&&!parsed);
    assert(ds4_resident_pool_native_recheck_parse("0",&parsed)&&!parsed);
    assert(ds4_resident_pool_native_recheck_parse("1",&parsed)&&parsed);
    const char *bad[]={"01","00","-1","+1"," 1","1 ","1.0","true","2","nan","999999999999999999999"};
    for(unsigned i=0;i<sizeof(bad)/sizeof(*bad);i++)assert(!ds4_resident_pool_native_recheck_parse(bad[i],&parsed));
    assert(!ds4_resident_pool_native_recheck_parse("1",NULL));
    for(unsigned i=0;i<sizeof(source);i++)source[i]=(unsigned char)i;
    char path[]="speed-bench/ideas/artifacts/resident-pool-recheck-cpu/file-XXXXXX";int fd=mkstemp(path);assert(fd>=0);unlink(path);assert(write(fd,source,sizeof(source))==sizeof(source));
    for(int i=0;i<4;i++)queued_change(fd,i);bounded_queue(fd);foreign_owner();close(fd);
    puts("PASS: real queued-to-native admission rejection, stale spans/generation/quant tuple, bounded40, preserved latest authority, owner-only callback, strict literal gate and fd/read/free balances");
}
