"""Check literal unchanged native/policy bodies against the frozen c3 parent."""
from pathlib import Path
import hashlib,json,re,sys
base=Path(sys.argv[1]);root=Path(__file__).resolve().parents[1]
def digest(b): return hashlib.sha256(b).hexdigest()
def body(source,name):
    # Definitions begin at column zero; signature cannot cross a semicolon.
    m=re.search(r"(?m)^[^\n;{}]*\b"+re.escape(name)+r"\([^;{}]*\)\s*\{",source)
    assert m,name
    start=source.index("{",m.start());depth=1;at=start+1
    while depth:
        depth+=(source[at]=="{")-(source[at]=="}");at+=1
    return source[start:at]
checks={}
for name in ["ds4_resident_stage.h","ds4_resident_late.h","ds4_resident_route.h"]:
    old=(base/name).read_bytes();new=(root/name).read_bytes();assert new==old,name;checks[name]=digest(new)
functions={"ds4.c":["ds41_resident_route_apply","ds41_moe_partial"],"ds4_metal.m":[
    "ds4_gpu_stream_expert_cache_get_protected","ds4_gpu_stream_expert_cache_begin_selected_load",
    "ds4_gpu_stream_expert_pending_load_finish","ds4_gpu_stream_expert_cache_install_loaded",
    "ds4_gpu_routed_moe_one_tensor","ds4_gpu_stream_expert_cache_finish_selected_load",
    "ds4_gpu_stream_expert_backfill_install_ready","ds4_gpu_stream_expert_backfill_reset_for_model"]}
for file,names in functions.items():
    old=(base/file).read_text();new=(root/file).read_text()
    for name in names:
        before=body(old,name);after=body(new,name);assert after==before,name
        checks[name]=digest(after.encode())
for p in sorted((root/"metal").glob("*.metal")):
    assert p.read_bytes()==(base/"metal"/p.name).read_bytes(),p.name;checks[str(p.relative_to(root))]=digest(p.read_bytes())
print(json.dumps({"literal_equal":checks,"model_bit_parity":"pending model controls; source equality does not prove execution parity"},indent=2))
