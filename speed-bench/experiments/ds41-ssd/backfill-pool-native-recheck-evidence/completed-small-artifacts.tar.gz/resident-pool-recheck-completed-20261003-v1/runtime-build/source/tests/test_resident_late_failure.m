/* Exercise the actual installer and ownership cleanup with CPU backing
 * buffers. No MTLDevice is created, model opened, command buffer submitted,
 * original pread issued or worker started. Only this translation unit has
 * the post-detach fault hook; production compilation has no hook. */
static void ds4_test_after_detach(void);
#define DS4_RESIDENT_LATE_TEST_AFTER_DETACH ds4_test_after_detach
#include "../ds4_metal.m"
#include <assert.h>

@interface DS4LateFakeBuffer : NSObject {
    void *_bytes;
    NSUInteger _length;
}
@property(nonatomic) BOOL zeroAddress;
- (instancetype)initWithLength:(NSUInteger)length;
- (void *)contents;
- (NSUInteger)length;
- (uint64_t)gpuAddress;
@end
@implementation DS4LateFakeBuffer
- (instancetype)initWithLength:(NSUInteger)length {
    self = [super init];
    if (self) {
        _length = length;
        assert(!posix_memalign(&_bytes, (size_t)getpagesize(), length));
        memset(_bytes, 0, length);
    }
    return self;
}
- (void *)contents { return _bytes; }
- (NSUInteger)length { return _length; }
- (uint64_t)gpuAddress { return self.zeroAddress ? 0 : (uint64_t)(uintptr_t)_bytes; }
- (void)dealloc { free(_bytes); }
@end

static int ds4_test_fault;
static int ds4_test_pool;
static __strong DS4LateFakeBuffer *ds4_test_gate;
static void ds4_test_after_detach(void) {
    if (ds4_test_fault == 1) {
        if (ds4_test_pool) g_stream_original_pool.ready[3].id.generation++;
        else g_stream_original_stage.identity.generation++;
    }
    if (ds4_test_fault == 2) ds4_test_gate.zeroAddress = YES;
}

static void check_case(int kind, int fault, int pool) {
    /* kind0=slab,1=explicit combined,2=three distinct explicit buffers;
     * fault0=success,1=actual stage-copy mismatch,2=actual address-install
     * failure,3=zero GPU address before detach (nondestructive decline). */
    const size_t page = (size_t)getpagesize();
    uint8_t model[4096] = {0};
    const uint32_t layer = 3, original = 1, victim_layer = 2, victim_expert = 7;
    ds4_gpu_stream_expert_table table = {.model_map=model,.model_size=sizeof(model),
        .layer=layer,.n_total_expert=8,.gate_offset=0,.up_offset=1024,.down_offset=2048,
        .gate_expert_bytes=128,.down_expert_bytes=64,.gate_type=22,.up_type=22,.down_type=8};
    int32_t protect[7] = {0,2,3,4,5,6,1};
    DS4LateFakeBuffer *gate = [[DS4LateFakeBuffer alloc] initWithLength:page];
    DS4LateFakeBuffer *up = kind == 2 ? [[DS4LateFakeBuffer alloc] initWithLength:page] : gate;
    DS4LateFakeBuffer *down = kind == 2 ? [[DS4LateFakeBuffer alloc] initWithLength:page] : gate;
    ds4_test_gate = gate; ds4_test_fault = fault; ds4_test_pool=pool;
    assert(!mlock([gate contents], page));
    if (kind == 2) { assert(!mlock([up contents],page)); assert(!mlock([down contents],page)); }
    const uint64_t locked = page * (kind == 2 ? 3 : 1);
    g_ssd_streaming_mode = 1;
    /* Non-Metal owner sentinel; all existing address buffers are CPU fakes,
     * so native ensure-address never invokes a device allocation method. */
    g_device = (id<MTLDevice>)[NSObject new];
    DS4LateFakeBuffer *addresses[3];
    for (int i=0;i<3;i++) addresses[i] = [[DS4LateFakeBuffer alloc] initWithLength:page];
    g_stream_expert_cache_gate_addr_buffers[layer] = (id<MTLBuffer>)addresses[0];
    g_stream_expert_cache_up_addr_buffers[layer] = (id<MTLBuffer>)addresses[1];
    g_stream_expert_cache_down_addr_buffers[layer] = (id<MTLBuffer>)addresses[2];
    ds4_gpu_stream_expert_cache_entry *victim = &g_stream_expert_cache[victim_layer][victim_expert];
    victim->gate_buffer=(id<MTLBuffer>)gate; victim->up_buffer=(id<MTLBuffer>)up;
    victim->down_buffer=(id<MTLBuffer>)down; victim->gate_inner=0;
    victim->up_inner=kind==2 ? 0 : 128; victim->down_inner=kind==2 ? 0 : 256;
    victim->model_map=model; victim->model_size=sizeof(model);
    victim->gate_expert_bytes=128; victim->down_expert_bytes=64;
    victim->logical_bytes=320; victim->last_used=10; victim->valid=1;
    victim->slab_backed=kind==0; victim->slab_slot=0;
    g_stream_expert_cache_entry_count=1; g_stream_expert_cache_layer_count[victim_layer]=1;
    g_stream_expert_cache_bytes=320; g_stream_expert_cache_mlock_bytes=locked;
    g_stream_expert_cache_evictions=0; g_stream_expert_cache_layer_evictions[victim_layer]=0;
    g_stream_expert_cache_misses=0; g_stream_expert_cache_layer_misses[layer]=0;
    g_stream_expert_cache_free_slot_count=0;
    if (kind==0) {
        g_stream_expert_cache_slabs[0]=(id<MTLBuffer>)gate;
        g_stream_expert_cache_slab_count=1; g_stream_expert_cache_slab_start_slot[0]=0;
        g_stream_expert_cache_slab_slot_count[0]=1; g_stream_expert_cache_slab_slots_used[0]=1;
        g_stream_expert_cache_slab_total_slots=1; g_stream_expert_cache_slab_slot_bytes=page;
        g_stream_expert_cache_slab_slot_locked[0]=1;
    }
    memset(&g_stream_original_late_metrics,0,sizeof(g_stream_original_late_metrics));
    memset(&g_stream_original_stage,0,sizeof(g_stream_original_stage));
    g_stream_original_stage.fd=-1;
    assert(ds4_gpu_stream_original_identity(&table,original,&g_stream_original_stage.identity));
    g_stream_original_stage.size=320; g_stream_original_stage.bytes=malloc(320);
    memset(g_stream_original_stage.bytes,0x5d,320);
    __atomic_store_n(&g_stream_original_stage.state,DS4_STAGE_READY,__ATOMIC_RELEASE);
    if (pool) {
        memset(&g_stream_original_pool,0,sizeof(g_stream_original_pool));
        assert(ds4_pool_init(&g_stream_original_pool,DS4_RESIDENT_POOL_LIMIT));
        ds4_resident_pool_payload *r=&g_stream_original_pool.ready[layer];
        r->id=g_stream_original_stage.identity;r->size=320;r->capacity=g_stream_original_pool.page;
        r->bytes=mmap(NULL,(size_t)r->capacity,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANON,-1,0);
        assert(r->bytes!=MAP_FAILED);memset(r->bytes,0x5d,320);
        g_stream_original_pool.payload_live=r->capacity;g_stream_original_pool.ready_count=1;
        g_stream_original_pool.model_map=model;g_stream_original_pool.model_size=sizeof(model);
        DS4_PC(&g_stream_original_pool,allocations,1);DS4_PC(&g_stream_original_pool,allocated_bytes,r->capacity);
        ds4_resident_stage_release(&g_stream_original_stage);
        g_stream_original_pool_enabled=1;
        ds4_gpu_stream_expert_backfill_pool_metrics before,after;
        assert(ds4_gpu_stream_expert_backfill_pool_metrics_read(&before));
        ds4_gpu_stream_expert_backfill_reset_for_model(model+1); /* unrelated model */
        assert(g_stream_original_pool.ready_count==1 && g_stream_original_pool_enabled);
        assert(ds4_gpu_stream_expert_backfill_pool_metrics_read(&after));
        assert(!memcmp(&before,&after,sizeof(before))); /* snapshot never kicks/polls */
    }
    if (fault==3) gate.zeroAddress=YES;
    int rc=ds4_gpu_stream_expert_backfill_install_ready(&table,original,protect,7);
    ds4_gpu_stream_expert_cache_entry *target=&g_stream_expert_cache[layer][original];
    assert(!g_batch_cb && !g_batch_has_work && !g_stream_expert_pending_load.active);
    assert(!g_stream_original_stage.counters.pread_calls && !g_stream_original_stage.thread_started);
    if (fault==3) {
        assert(rc==0 && victim->valid && !target->valid);
        assert(g_stream_expert_cache_entry_count==1 && g_stream_expert_cache_bytes==320);
        assert(!g_stream_expert_cache_evictions && !g_stream_original_late_metrics.install_failures);
        assert(g_stream_original_late_metrics.no_victim==1 && !g_stream_original_stage.counters.consumed);
        assert(g_stream_expert_cache_mlock_bytes==locked && !g_stream_expert_cache_free_slot_count);
        gate.zeroAddress=NO;
        ds4_gpu_stream_expert_cache_clear_entry(victim_layer,victim_expert,0);
    } else if (fault) {
        assert(rc==-1 && !victim->valid && !target->valid);
        assert(g_stream_expert_cache_entry_count==0 && !g_stream_expert_cache_bytes);
        assert(g_stream_expert_cache_evictions==1 && g_stream_original_late_metrics.install_failures==1);
        assert(!g_stream_original_late_metrics.installs);
        assert(pool ? g_stream_original_pool.counters.consumed_late==(uint64_t)(fault==2) :
            g_stream_original_stage.counters.consumed==(uint64_t)(fault==2));
        for (int i=0;i<3;i++) assert(!((uint64_t *)[addresses[i] contents])[original]);
        if (kind==0) {
            assert(g_stream_expert_cache_free_slot_count==1 && g_stream_expert_cache_free_slots[0]==0);
            assert(g_stream_expert_cache_slab_slot_locked[0] && g_stream_expert_cache_mlock_bytes==locked);
            id<MTLBuffer> a=nil,b=nil,c=nil; NSUInteger ai=0,bi=0,ci=0;
            assert(ds4_gpu_stream_expert_alloc_slab_slot(128,64,&a,&b,&c,&ai,&bi,&ci));
            assert(a==(id<MTLBuffer>)gate && b==a && c==a && !g_stream_expert_cache_free_slot_count);
            assert(g_stream_expert_cache_mlock_bytes==locked);
        } else assert(!g_stream_expert_cache_mlock_bytes && !g_stream_expert_cache_free_slot_count);
    } else {
        assert(rc==1 && !victim->valid && target->valid);
        assert(g_stream_expert_cache_entry_count==1 && g_stream_expert_cache_bytes==320);
        assert(g_stream_original_late_metrics.installs==1 && !g_stream_original_late_metrics.install_failures);
        assert(pool ? g_stream_original_pool.counters.consumed_late==1 && !g_stream_original_pool.ready_count :
            g_stream_original_stage.counters.consumed==1 && !g_stream_original_stage.bytes);
        assert(g_stream_expert_cache_mlock_bytes==locked);
        assert(((uint8_t *)[target->gate_buffer contents])[target->gate_inner]==0x5d);
        ds4_gpu_stream_expert_cache_clear_entry(layer,original,0);
    }
    if (kind==0) assert(ds4_gpu_stream_expert_slab_unlock_slot(0));
    assert(!g_stream_expert_cache_mlock_bytes);
    ds4_resident_stage_release(&g_stream_original_stage);
    if (pool) {
        ds4_gpu_stream_expert_backfill_reset_for_model(model);
        assert(!g_stream_original_pool_enabled && !g_stream_original_pool.ready_count && !g_stream_original_pool.payload_live);
        assert(g_stream_original_pool.counters.allocations==g_stream_original_pool.counters.frees);
    }
    memset(victim,0,sizeof(*victim)); memset(target,0,sizeof(*target));
    g_stream_expert_cache_layer_count[layer]=g_stream_expert_cache_layer_count[victim_layer]=0;
    g_stream_expert_cache_entry_count=0; g_stream_expert_cache_bytes=0;
    g_stream_expert_cache_gate_addr_buffers[layer]=nil;
    g_stream_expert_cache_up_addr_buffers[layer]=nil;
    g_stream_expert_cache_down_addr_buffers[layer]=nil;
    g_stream_expert_cache_slabs[0]=nil; g_stream_expert_cache_slab_count=0;
    g_stream_expert_cache_slab_total_slots=0; g_stream_expert_cache_slab_slot_bytes=0;
    g_stream_expert_cache_free_slot_count=0; ds4_test_gate=nil; g_device=nil; g_ssd_streaming_mode=0;
}

int main(void) {
    setenv("DS4_METAL_ENABLE_STREAMING_EXPERT_ADDR_TABLE","1",1);
    @autoreleasepool {
        for (int pool=0;pool<2;pool++) for (int kind=0;kind<3;kind++) for (int fault=0;fault<4;fault++) check_case(kind,fault,pool);
    }
    puts("PASS:24 global/pool actual-installer CPU cases; copy/install failure, native slab reuse and locked bytes, decline/success; owner-only snapshot and matching-model reset; no Metal/model/worker/pread");
    return 0;
}
