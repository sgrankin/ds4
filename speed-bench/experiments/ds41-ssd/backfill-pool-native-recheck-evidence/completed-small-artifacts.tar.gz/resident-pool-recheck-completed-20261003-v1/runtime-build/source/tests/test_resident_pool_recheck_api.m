/* Actual Metal metadata callback and public API with CPU-backed fake buffers.
 * No MTLDevice, command buffer, GPU operation or model is opened. */
#include "../ds4_metal.m"
#include <assert.h>
@interface DS4RecheckFakeBuffer : NSObject { void *_bytes;NSUInteger _length; }
- (instancetype)initWithLength:(NSUInteger)length;
- (void *)contents;
- (NSUInteger)length;
@end
@implementation DS4RecheckFakeBuffer
- (instancetype)initWithLength:(NSUInteger)length {self=[super init];if(self){_length=length;_bytes=calloc(1,length);assert(_bytes);}return self;}
- (void *)contents {return _bytes;}
- (NSUInteger)length {return _length;}
- (void)dealloc {free(_bytes);}
@end
int main(void) {
    uint8_t data[4096];for(unsigned i=0;i<sizeof(data);i++)data[i]=(uint8_t)i;
    char path[]="speed-bench/ideas/artifacts/resident-pool-recheck-cpu/api-XXXXXX";
    int fd=mkstemp(path);assert(fd>=0);unlink(path);assert(write(fd,data,sizeof(data))==sizeof(data));
    ds4_gpu_set_ssd_streaming(true);assert(ds4_gpu_set_model_fd(fd));assert(!g_device);
    assert(!ds4_gpu_stream_expert_backfill_pool_enable_native_recheck());
    assert(ds4_gpu_stream_expert_backfill_pool_enable_ready_age(1600));
    assert(ds4_gpu_stream_expert_backfill_pool_enable_native_recheck());
    const uint32_t layer=3,expert=1;
    ds4_gpu_stream_expert_table table={.model_map=data,.model_size=sizeof(data),.layer=layer,.n_total_expert=8,
        .gate_offset=0,.up_offset=1024,.down_offset=2048,.gate_expert_bytes=128,.down_expert_bytes=64,
        .gate_type=22,.up_type=22,.down_type=8};
    ds4_resident_stage_identity identity;assert(ds4_gpu_stream_original_identity(&table,expert,&identity));
    DS4RecheckFakeBuffer *buf=[[DS4RecheckFakeBuffer alloc] initWithLength:4096];
    ds4_gpu_stream_expert_cache_entry *e=&g_stream_expert_cache[layer][expert];
    e->gate_buffer=(id<MTLBuffer>)buf;e->up_buffer=(id<MTLBuffer>)buf;e->down_buffer=(id<MTLBuffer>)buf;
    e->gate_inner=0;e->up_inner=128;e->down_inner=256;e->model_map=data;e->model_size=sizeof(data);
    e->gate_abs_offset=identity.offsets[0];e->up_abs_offset=identity.offsets[1];e->down_abs_offset=identity.offsets[2];
    e->gate_expert_bytes=128;e->down_expert_bytes=64;e->valid=1;e->last_used=23;e->use_count=7;
    const uint64_t hits=g_stream_expert_cache_hits,misses=g_stream_expert_cache_misses,clock=g_stream_expert_cache_clock;
    uint32_t hot=g_stream_expert_cache_route_hotness[layer][expert];
    assert(ds4_gpu_stream_expert_backfill_request(&table,expert));
    ds4_gpu_stream_expert_backfill_pool_recheck_metrics r,before;
    assert(ds4_gpu_stream_expert_backfill_pool_recheck_metrics_read(&r));
    assert(r.enabled && r.admission_rechecks==1 && r.queue_native_resident_drops==1 && r.not_started_bytes==320 && !r.owner_rejections);
    assert(!g_stream_original_pool.worker && !g_stream_original_pool.queue_count && !g_stream_original_pool.counters.allocations && !g_stream_original_pool.counters.dup_opens);
    before=r;assert(ds4_gpu_stream_expert_backfill_pool_recheck_metrics_read(&r));assert(!memcmp(&r,&before,sizeof(r)));
    assert(ds4_gpu_stream_pool_native_resident(NULL,&identity));
    ds4_resident_stage_identity bad=identity;bad.generation++;assert(!ds4_gpu_stream_pool_native_resident(NULL,&bad));
    bad=identity;bad.quant_types[0]++;assert(!ds4_gpu_stream_pool_native_resident(NULL,&bad));
    bad=identity;bad.model_map=data+1;assert(!ds4_gpu_stream_pool_native_resident(NULL,&bad));
    bad=identity;bad.offsets[0]++;assert(!ds4_gpu_stream_pool_native_resident(NULL,&bad));
    e->gate_abs_offset++;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->gate_abs_offset--;
    e->model_size--;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->model_size++;
    e->down_expert_bytes++;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->down_expert_bytes--;
    e->valid=0;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->valid=1;
    e->gate_buffer=nil;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->gate_buffer=(id<MTLBuffer>)buf;
    e->up_buffer=nil;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->up_buffer=(id<MTLBuffer>)buf;
    e->down_buffer=nil;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->down_buffer=(id<MTLBuffer>)buf;
    e->up_inner=4090;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->up_inner=128;
    e->gate_inner=5000;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));e->gate_inner=0;
    e->inflight_seq=1;g_stream_expert_cache_done_seq=0;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));
    g_stream_expert_cache_done_seq=1;assert(ds4_gpu_stream_pool_native_resident(NULL,&identity));e->inflight_seq=0;
    g_stream_expert_pending_load.active=1;g_stream_expert_pending_load.model_map=data;g_stream_expert_pending_load.model_size=sizeof(data);g_stream_expert_pending_load.layer=layer;g_stream_expert_pending_load.n_selected=1;g_stream_expert_pending_load.selected_ids[0]=expert;
    assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));g_stream_expert_pending_load.selected_ids[0]=2;assert(ds4_gpu_stream_pool_native_resident(NULL,&identity));
    g_stream_expert_pending_load.n_selected=DS4_METAL_STREAM_EXPERT_CACHE_MAX_SELECTED+1;assert(!ds4_gpu_stream_pool_native_resident(NULL,&identity));
    g_stream_expert_pending_load.active=0;g_stream_expert_pending_load.n_selected=0;
    assert(g_stream_expert_cache_hits==hits && g_stream_expert_cache_misses==misses && g_stream_expert_cache_clock==clock);
    assert(e->last_used==23 && e->use_count==7 && g_stream_expert_cache_route_hotness[layer][expert]==hot);
    /* A partial/unpublished entry must retain the real background read. */
    e->valid=0;assert(ds4_gpu_stream_expert_backfill_request(&table,expert));
    struct timespec pause={0,1000000};int ready=0;
    for(int i=0;i<3000;i++){if(ds4_gpu_stream_expert_backfill_ready(&table,expert)){ready=1;break;}nanosleep(&pause,NULL);}assert(ready);
    assert(g_stream_original_pool.counters.read_started==1 && g_stream_original_pool.counters.completed==1 && g_stream_original_pool.counters.pread_calls==3);
    assert(g_stream_original_pool.counters.requested_bytes==320 && g_stream_original_pool.counters.returned_bytes==320);
    unsigned char bytes[320],*dest[3]={bytes,bytes+128,bytes+256};assert(ds4_pool_copy(&g_stream_original_pool,&identity,dest,0));
    assert(!memcmp(bytes,data+identity.offsets[0],128) && !memcmp(bytes+128,data+identity.offsets[1],128) && !memcmp(bytes+256,data+identity.offsets[2],64));
    assert(ds4_gpu_stream_expert_backfill_pool_recheck_metrics_read(&r));assert(r.queue_native_resident_drops==1 && r.admission_rechecks==2);
    assert(g_stream_expert_cache_hits==hits && g_stream_expert_cache_misses==misses && e->use_count==7);
    ds4_gpu_stream_expert_backfill_reset_for_model(data);assert(!g_stream_original_pool.native_recheck && !g_stream_original_pool.worker);
    assert(g_stream_original_pool.counters.allocations==g_stream_original_pool.counters.frees && g_stream_original_pool.counters.dup_opens==g_stream_original_pool.counters.dup_closes);
    assert(!g_device && ds4_gpu_set_model_fd(-1));close(fd);ds4_gpu_set_ssd_streaming(false);
    e->gate_buffer=nil;e->up_buffer=nil;e->down_buffer=nil;
    puts("PASS: actual native cache callback rejects stale generation/model/span/type, partial/pending/inflight and invalid backing ranges; complete resident avoids read/dup/allocation; real false path and read-only counters/reset; no Metal device/model");
}
