#ifndef DS4_RESIDENT_POOL_H
#define DS4_RESIDENT_POOL_H
/* Owner-only queue/READY storage, one persistent private reader. No cache,
 * Metal, mapped-model dereference, descriptor-policy mutation or hot join. */
#include "ds4_resident_stage.h"
#include <sys/mman.h>

#define DS4_RESIDENT_POOL_LAYERS 40u
#define DS4_RESIDENT_POOL_LIMIT (UINT64_C(400) * 1024 * 1024)
#define DS4_RESIDENT_POOL_STACK (256u * 1024u)
#define DS4_RESIDENT_POOL_AGE 80u
#define DS4_POOL_COUNTERS(X) \
 X(requests) X(invalid_requests) X(dedup_ready) X(dedup_reading) X(dedup_queued) \
 X(queued) X(queue_updates) X(queue_expired) X(queue_ready_drops) X(queue_reading_drops) \
 X(admissions) X(busy_defers) X(handoff_defers) X(budget_defers) \
 X(worker_starts) X(worker_start_failures) X(read_started) X(completed) X(failed) \
 X(pread_calls) X(requested_bytes) X(returned_bytes) \
 X(allocations) X(allocation_failures) X(frees) X(free_failures) \
 X(allocated_bytes) X(freed_bytes) X(dup_opens) X(dup_closes) X(dup_failures) \
 X(consumed_future) X(consumed_late) X(copied_bytes) X(ready_replaced) X(ready_expired) X(ready_superseded) X(ready_superseded_bytes) \
 X(completion_harvest_expired) X(stored_ready_expired) \
 X(consumed_future_age_sum) X(consumed_future_age_max) X(consumed_future_older80) \
 X(consumed_late_age_sum) X(consumed_late_age_max) X(consumed_late_older80) \
 X(reset_ready_discards) X(reset_result_discards) X(reset_queue_discards) X(resets) X(joins)
typedef struct {
#define DS4_POOL_FIELD(name) uint64_t name;
    DS4_POOL_COUNTERS(DS4_POOL_FIELD)
#undef DS4_POOL_FIELD
} ds4_resident_pool_counters;
typedef struct {
    ds4_resident_stage_identity id;
    uint8_t *bytes;
    uint64_t size, capacity, admission_step;
} ds4_resident_pool_payload;
typedef struct {
    ds4_resident_stage_identity id;
    uint64_t request_step, sequence;
    int source_fd, valid;
} ds4_resident_pool_request;
/* Invoked only by the configured owner, never by the private reader. Return
 * exactly1 only for fully loaded native data; error/unknown0 keeps the read. */
typedef int (*ds4_resident_pool_native_recheck)(void *,const ds4_resident_stage_identity *);
typedef struct {
    uint64_t admission_rechecks, queue_native_resident_drops, not_started_bytes, owner_rejections;
} ds4_resident_pool_recheck_counters;
enum { DS4_POOL_IDLE, DS4_POOL_OFFERED, DS4_POOL_READING, DS4_POOL_READY, DS4_POOL_FAILED };
typedef struct {
    ds4_resident_pool_payload ready[DS4_RESIDENT_POOL_LAYERS], job;
    ds4_resident_pool_request queue[DS4_RESIDENT_POOL_LAYERS];
    ds4_resident_stage_identity latest[DS4_RESIDENT_POOL_LAYERS];
    uint8_t latest_valid[DS4_RESIDENT_POOL_LAYERS];
    ds4_resident_pool_counters counters;
    ds4_resident_pool_recheck_counters recheck_counters;
    ds4_resident_pool_native_recheck native_recheck;
    void *native_recheck_context;
    pthread_t native_recheck_owner;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    pthread_t thread;
    int initialized, synchronization, worker, stop, pending, state, job_fd;
    uint64_t limit, page, metadata_bytes, stack_bytes, guard_bytes;
    uint64_t payload_live, payload_peak, owned_peak, step, sequence;
    uint32_t ready_count, ready_peak, queue_count, queue_peak, ready_age;
    const void *model_map;
    uint64_t model_size, generation;
} ds4_resident_pool;
#define DS4_PC(pool,name,n) __atomic_fetch_add(&(pool)->counters.name,(uint64_t)(n),__ATOMIC_RELAXED)

static inline int ds4_pool_identity_equal(const ds4_resident_stage_identity *a,
        const ds4_resident_stage_identity *b) {
    return a && b && a->model_map==b->model_map && a->model_size==b->model_size &&
        a->layer==b->layer && a->expert==b->expert && a->generation==b->generation &&
        !memcmp(a->quant_types,b->quant_types,sizeof(a->quant_types)) &&
        !memcmp(a->offsets,b->offsets,sizeof(a->offsets)) && !memcmp(a->lengths,b->lengths,sizeof(a->lengths));
}
static inline int ds4_pool_state(const ds4_resident_pool *p) {
    return __atomic_load_n(&p->state,__ATOMIC_ACQUIRE);
}
static inline uint64_t ds4_pool_owned(const ds4_resident_pool *p) {
    return p->metadata_bytes+p->stack_bytes+p->guard_bytes+p->payload_live;
}
static inline uint64_t ds4_pool_round(uint64_t n,uint64_t page) {
    return page && n<=UINT64_MAX-(page-1) ? ((n+page-1)/page)*page : 0;
}
static inline int ds4_pool_init(ds4_resident_pool *p,uint64_t limit) {
    if (!p || !limit || limit>DS4_RESIDENT_POOL_LIMIT) return 0;
    if (p->initialized) return p->limit==limit;
    const long page=sysconf(_SC_PAGESIZE);
    if (page<=0) return 0;
    p->limit=limit; p->page=(uint64_t)page;
    p->metadata_bytes=ds4_pool_round(sizeof(*p),p->page);
    if (!p->metadata_bytes || p->metadata_bytes>=limit) return 0;
    p->job_fd=-1; p->initialized=1; p->owned_peak=p->metadata_bytes;
    p->ready_age=DS4_RESIDENT_POOL_AGE;
    return 1;
}
/* Owner-only setup; changing lifetime while ownership is active is forbidden. */
static inline int ds4_pool_set_ready_age(ds4_resident_pool *p,uint32_t age) {
    if (!p || !p->initialized || age<DS4_RESIDENT_POOL_AGE || age>1600) return 0;
    if (p->ready_age==age) return 1;
    if (p->payload_live || p->queue_count || p->worker || ds4_pool_state(p)!=DS4_POOL_IDLE) return 0;
    p->ready_age=age;return 1;
}
/* Setup is immutable while any queue/payload/worker is owned. A reset clears
 * the callback before a new model/owner can configure it again. */
static inline int ds4_pool_set_native_recheck(ds4_resident_pool *p,
        ds4_resident_pool_native_recheck callback,void *context) {
    if (!p || !p->initialized || !callback) return 0;
    if (p->native_recheck==callback && p->native_recheck_context==context)
        return pthread_equal(p->native_recheck_owner,pthread_self());
    if (p->payload_live || p->queue_count || p->worker || ds4_pool_state(p)!=DS4_POOL_IDLE) return 0;
    p->native_recheck=callback;p->native_recheck_context=context;p->native_recheck_owner=pthread_self();return 1;
}
static inline int ds4_pool_valid(const ds4_resident_stage_identity *id,uint64_t *size) {
    if (!id || !size || !id->model_map || !id->model_size || id->layer>=DS4_RESIDENT_POOL_LAYERS) return 0;
    uint64_t sum=0;
    for (uint32_t i=0;i<3;i++) {
        if (!id->lengths[i] || id->offsets[i]>id->model_size || id->lengths[i]>id->model_size-id->offsets[i] ||
            id->offsets[i]>(uint64_t)LLONG_MAX || id->lengths[i]>(uint64_t)LLONG_MAX-id->offsets[i] ||
            id->lengths[i]>UINT64_C(16)*1024*1024-sum) return 0;
        sum+=id->lengths[i];
    }
    if (sum>SIZE_MAX) return 0;
    *size=sum;return 1;
}
static inline int ds4_pool_free(ds4_resident_pool *p,ds4_resident_pool_payload *r) {
    if (!r->bytes) return 1;
    if (munmap(r->bytes,(size_t)r->capacity)) { DS4_PC(p,free_failures,1);return 0; }
    p->payload_live-=r->capacity;
    DS4_PC(p,frees,1);DS4_PC(p,freed_bytes,r->capacity);
    memset(r,0,sizeof(*r));return 1;
}
static void *ds4_pool_worker(void *opaque) {
    ds4_resident_pool *p=opaque;
#ifdef __APPLE__
    (void)pthread_set_qos_class_self_np(QOS_CLASS_BACKGROUND,0);
#endif
    for (;;) {
        pthread_mutex_lock(&p->mutex);
        while (!p->pending && !p->stop) pthread_cond_wait(&p->cond,&p->mutex);
        if (!p->pending && p->stop) { pthread_mutex_unlock(&p->mutex);return NULL; }
        const ds4_resident_pool_payload job=p->job;
        const int fd=p->job_fd;
        p->pending=0;
        __atomic_store_n(&p->state,DS4_POOL_READING,__ATOMIC_RELEASE);
        pthread_mutex_unlock(&p->mutex);
        DS4_PC(p,read_started,1);
#ifdef DS4_RESIDENT_POOL_TEST_BEFORE_READ
        DS4_RESIDENT_POOL_TEST_BEFORE_READ(p);
#endif
        uint64_t base=0;int ok=1;
        for (uint32_t tensor=0;tensor<3 && ok;tensor++) {
            uint64_t pos=0,len=job.id.lengths[tensor];
            while (pos<len) {
                const uint64_t remain=len-pos;
                const size_t want=remain>(uint64_t)SSIZE_MAX ? (size_t)SSIZE_MAX : (size_t)remain;
                DS4_PC(p,pread_calls,1);DS4_PC(p,requested_bytes,want);
                const ssize_t n=pread(fd,job.bytes+base+pos,want,(off_t)(job.id.offsets[tensor]+pos));
                if (n<0 && errno==EINTR) continue;
                if (n<=0) { ok=0;break; }
                DS4_PC(p,returned_bytes,(uint64_t)n);pos+=(uint64_t)n;
            }
            base+=len;
        }
        (void)close(fd);DS4_PC(p,dup_closes,1);
        p->job_fd=-1;
        DS4_PC(p,completed,ok!=0);DS4_PC(p,failed,ok==0);
        /* Final job/payload access; owner acquire can harvest/free without
         * joining this persistent thread, which next waits only on its mutex. */
        __atomic_store_n(&p->state,ok ? DS4_POOL_READY : DS4_POOL_FAILED,__ATOMIC_RELEASE);
    }
}
static inline int ds4_pool_ensure_worker(ds4_resident_pool *p) {
    if (p->worker) return 1;
    const uint64_t stack=ds4_pool_round(DS4_RESIDENT_POOL_STACK,p->page);
    if (!stack || stack>p->limit-p->metadata_bytes || p->page>p->limit-p->metadata_bytes-stack) {
        DS4_PC(p,budget_defers,1);return 0;
    }
    if (!p->synchronization) {
        if (pthread_mutex_init(&p->mutex,NULL)) { DS4_PC(p,worker_start_failures,1);return 0; }
        if (pthread_cond_init(&p->cond,NULL)) {
            pthread_mutex_destroy(&p->mutex);DS4_PC(p,worker_start_failures,1);return 0;
        }
        p->synchronization=1;
    }
    pthread_attr_t attr;
    if (pthread_attr_init(&attr)) { DS4_PC(p,worker_start_failures,1);return 0; }
    int err=pthread_attr_setstacksize(&attr,(size_t)stack);
    if (!err) err=pthread_attr_setguardsize(&attr,(size_t)p->page);
    p->stop=0;p->pending=0;
    if (!err) err=pthread_create(&p->thread,&attr,ds4_pool_worker,p);
    pthread_attr_destroy(&attr);
    if (err) { DS4_PC(p,worker_start_failures,1);return 0; }
    p->worker=1;p->stack_bytes=stack;p->guard_bytes=p->page;
#ifdef __APPLE__
    p->stack_bytes=(uint64_t)pthread_get_stacksize_np(p->thread);
#endif
    DS4_PC(p,worker_starts,1);
    if (ds4_pool_owned(p)>p->owned_peak) p->owned_peak=ds4_pool_owned(p);
    return ds4_pool_owned(p)<=p->limit;
}
/* Harvest only: no admission, lock, join, queue kick or cache mutation. */
static inline void ds4_pool_poll(ds4_resident_pool *p) {
    const int state=ds4_pool_state(p);
    if (state!=DS4_POOL_READY && state!=DS4_POOL_FAILED) return;
    ds4_resident_pool_payload *job=&p->job;
    const uint32_t layer=job->id.layer;
    const int superseded=state==DS4_POOL_READY && p->latest_valid[layer] &&
        !ds4_pool_identity_equal(&job->id,&p->latest[layer]);
    if (state==DS4_POOL_FAILED || p->step-job->admission_step>p->ready_age || superseded) {
        const uint64_t discarded_size=job->size;
        if (!ds4_pool_free(p,job)) return;
        if (state==DS4_POOL_READY) {
            if (superseded) { DS4_PC(p,ready_superseded,1);DS4_PC(p,ready_superseded_bytes,discarded_size); }
            else { DS4_PC(p,ready_expired,1);DS4_PC(p,completion_harvest_expired,1); }
        }
    } else {
        ds4_resident_pool_payload *ready=&p->ready[job->id.layer];
        if (ready->bytes) {
            if (!ds4_pool_free(p,ready)) return;
            p->ready_count--;DS4_PC(p,ready_replaced,1);
        }
        *ready=*job;memset(job,0,sizeof(*job));p->ready_count++;
        if (p->ready_count>p->ready_peak) p->ready_peak=p->ready_count;
    }
    __atomic_store_n(&p->state,DS4_POOL_IDLE,__ATOMIC_RELEASE);
}
static inline void ds4_pool_expire(ds4_resident_pool *p) {
    for (uint32_t layer=0;layer<DS4_RESIDENT_POOL_LAYERS;layer++) {
        ds4_resident_pool_payload *r=&p->ready[layer];
        if (r->bytes && p->step-r->admission_step>p->ready_age && ds4_pool_free(p,r)) {
            p->ready_count--;DS4_PC(p,ready_expired,1);DS4_PC(p,stored_ready_expired,1);
        }
        ds4_resident_pool_request *q=&p->queue[layer];
        if (q->valid && p->step-q->request_step>DS4_RESIDENT_POOL_AGE) {
            q->valid=0;p->queue_count--;DS4_PC(p,queue_expired,1);
        }
    }
}
static inline void ds4_pool_tick(ds4_resident_pool *p) {
    if (!p->initialized) return;
    p->step++;ds4_pool_poll(p);ds4_pool_expire(p);
}
static inline int ds4_pool_ready(ds4_resident_pool *p,const ds4_resident_stage_identity *id) {
    if (!p->initialized || !id || id->layer>=DS4_RESIDENT_POOL_LAYERS) return 0;
    ds4_pool_poll(p);
    ds4_resident_pool_payload *r=&p->ready[id->layer];
    if (r->bytes && p->step-r->admission_step>p->ready_age && ds4_pool_free(p,r)) {
        p->ready_count--;DS4_PC(p,ready_expired,1);DS4_PC(p,stored_ready_expired,1);
    }
    return r->bytes && ds4_pool_identity_equal(&r->id,id);
}
/* Called only after this layer's mandatory selected demand is scheduled. */
static inline int ds4_pool_kick_legacy(ds4_resident_pool *p,uint32_t current) {
    /* An exceptional failed unmap must not lose its still-owned job pointer
     * by admitting another allocation after teardown. Leave ownership visible
     * for a later reset and fail closed until it has been released. */
    if (p->job.bytes && ds4_pool_state(p)==DS4_POOL_IDLE) return 0;
    if (ds4_pool_state(p)!=DS4_POOL_IDLE) { DS4_PC(p,busy_defers,1);return 0; }
    if (!p->queue_count || !ds4_pool_ensure_worker(p)) return 0;
    if (pthread_mutex_trylock(&p->mutex)) { DS4_PC(p,handoff_defers,1);return 0; }
    uint32_t chosen=DS4_RESIDENT_POOL_LAYERS;
    if (current<DS4_RESIDENT_POOL_LAYERS && p->queue[current].valid) chosen=current;
    else {
        uint64_t oldest=UINT64_MAX;
        for (uint32_t i=0;i<DS4_RESIDENT_POOL_LAYERS;i++)
            if (p->queue[i].valid && p->queue[i].sequence<oldest) { chosen=i;oldest=p->queue[i].sequence; }
    }
    if (chosen==DS4_RESIDENT_POOL_LAYERS) { pthread_mutex_unlock(&p->mutex);return 0; }
    ds4_resident_pool_request *q=&p->queue[chosen];
    uint64_t size=0;
    if (!ds4_pool_valid(&q->id,&size)) { pthread_mutex_unlock(&p->mutex);return 0; }
    const uint64_t capacity=ds4_pool_round(size,p->page),owned=ds4_pool_owned(p);
    if (!capacity || owned>p->limit || capacity>p->limit-owned) {
        DS4_PC(p,budget_defers,1);pthread_mutex_unlock(&p->mutex);return 0;
    }
#ifdef F_DUPFD_CLOEXEC
    int fd=fcntl(q->source_fd,F_DUPFD_CLOEXEC,0);
#else
    int fd=dup(q->source_fd);
    if (fd>=0 && fcntl(fd,F_SETFD,FD_CLOEXEC)) { close(fd);fd=-1; }
#endif
    if (fd<0) { DS4_PC(p,dup_failures,1);pthread_mutex_unlock(&p->mutex);return 0; }
    DS4_PC(p,dup_opens,1);
    void *bytes=mmap(NULL,(size_t)capacity,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANON,-1,0);
    if (bytes==MAP_FAILED) {
        close(fd);DS4_PC(p,dup_closes,1);DS4_PC(p,allocation_failures,1);
        pthread_mutex_unlock(&p->mutex);return 0;
    }
    DS4_PC(p,allocations,1);DS4_PC(p,allocated_bytes,capacity);
    p->payload_live+=capacity;
    if (p->payload_live>p->payload_peak) p->payload_peak=p->payload_live;
    if (ds4_pool_owned(p)>p->owned_peak) p->owned_peak=ds4_pool_owned(p);
    p->job=(ds4_resident_pool_payload){.id=q->id,.bytes=bytes,.size=size,.capacity=capacity,.admission_step=p->step};
    p->job_fd=fd;q->valid=0;p->queue_count--;p->pending=1;
    DS4_PC(p,admissions,1);
    __atomic_store_n(&p->state,DS4_POOL_OFFERED,__ATOMIC_RELEASE);
    pthread_cond_signal(&p->cond);pthread_mutex_unlock(&p->mutex);return 1;
}
/* One bounded40-entry owner-only metadata scan. The default branch delegates
 * to the literal legacy admission body, including all timing/FD/worker work.
 * Reject only known resident identities, before any worker setup/dup/mmap/read.
 * Latest identity authority is retained even when its queued read is dropped. */
static inline int ds4_pool_kick(ds4_resident_pool *p,uint32_t current) {
    if (!p->native_recheck) return ds4_pool_kick_legacy(p,current);
    if (!pthread_equal(p->native_recheck_owner,pthread_self())) {
        __atomic_fetch_add(&p->recheck_counters.owner_rejections,1,__ATOMIC_RELAXED);return 0;
    }
    if (ds4_pool_state(p)==DS4_POOL_IDLE && !p->job.bytes && p->queue_count) {
        for (uint32_t i=0;i<DS4_RESIDENT_POOL_LAYERS;i++) {
            ds4_resident_pool_request *q=&p->queue[i];uint64_t size=0;
            if (!q->valid || !ds4_pool_valid(&q->id,&size) ||
                q->id.model_map!=p->model_map || q->id.model_size!=p->model_size || q->id.generation!=p->generation ||
                !p->latest_valid[i] || !ds4_pool_identity_equal(&q->id,&p->latest[i])) continue;
            __atomic_fetch_add(&p->recheck_counters.admission_rechecks,1,__ATOMIC_RELAXED);
            if (p->native_recheck(p->native_recheck_context,&q->id)!=1) continue;
            q->valid=0;p->queue_count--;
            __atomic_fetch_add(&p->recheck_counters.queue_native_resident_drops,1,__ATOMIC_RELAXED);
            __atomic_fetch_add(&p->recheck_counters.not_started_bytes,size,__ATOMIC_RELAXED);
        }
    }
    return ds4_pool_kick_legacy(p,current);
}
static inline int ds4_pool_request(ds4_resident_pool *p,int fd,const ds4_resident_stage_identity *id) {
    DS4_PC(p,requests,1);uint64_t size=0;
    if (!p->initialized || fd<0 || !ds4_pool_valid(id,&size) ||
        (p->model_map && (p->model_map!=id->model_map || p->model_size!=id->model_size || p->generation!=id->generation))) {
        DS4_PC(p,invalid_requests,1);return 0;
    }
    p->model_map=id->model_map;p->model_size=id->model_size;p->generation=id->generation;
    /* Establish newest authority before harvest: a completed older read must
     * not replace the READY identity requested again at this boundary. */
    p->latest[id->layer]=*id;p->latest_valid[id->layer]=1;
    ds4_pool_poll(p);ds4_pool_expire(p);
    const uint32_t layer=id->layer;
    ds4_resident_pool_request *q=&p->queue[layer];
    if (p->ready[layer].bytes && ds4_pool_identity_equal(&p->ready[layer].id,id)) {
        /* This newest request is already available. An older queued request
         * for this layer must not later overwrite its READY payload. */
        if (q->valid) { q->valid=0;p->queue_count--;DS4_PC(p,queue_ready_drops,1); }
        DS4_PC(p,dedup_ready,1);(void)ds4_pool_kick(p,DS4_RESIDENT_POOL_LAYERS);return 1;
    }
    const int state=ds4_pool_state(p);
    if (state!=DS4_POOL_IDLE && ds4_pool_identity_equal(&p->job.id,id)) {
        if (q->valid) { q->valid=0;p->queue_count--;DS4_PC(p,queue_reading_drops,1); }
        DS4_PC(p,dedup_reading,1);return 1;
    }
    if (q->valid) {
        if (ds4_pool_identity_equal(&q->id,id)) DS4_PC(p,dedup_queued,1);
        else DS4_PC(p,queue_updates,1);
    } else { p->queue_count++;DS4_PC(p,queued,1); }
    *q=(ds4_resident_pool_request){.id=*id,.request_step=p->step,.sequence=++p->sequence,.source_fd=fd,.valid=1};
    if (p->queue_count>p->queue_peak) p->queue_peak=p->queue_count;
    (void)ds4_pool_kick(p,layer);return 1;
}
static inline int ds4_pool_copy(ds4_resident_pool *p,const ds4_resident_stage_identity *id,
        uint8_t *dest[3],int late) {
    if (!dest || !dest[0] || !dest[1] || !dest[2] || !ds4_pool_ready(p,id)) return 0;
    ds4_resident_pool_payload *r=&p->ready[id->layer];uint64_t at=0;
    for (uint32_t i=0;i<3;i++) { memcpy(dest[i],r->bytes+at,(size_t)id->lengths[i]);at+=id->lengths[i]; }
    DS4_PC(p,copied_bytes,at);
    const uint64_t age=p->step-r->admission_step;
    if (!ds4_pool_free(p,r)) return 0;
    if (late) {
        DS4_PC(p,consumed_late,1);DS4_PC(p,consumed_late_age_sum,age);
        if (age>__atomic_load_n(&p->counters.consumed_late_age_max,__ATOMIC_RELAXED))
            __atomic_store_n(&p->counters.consumed_late_age_max,age,__ATOMIC_RELAXED);
        if (age>DS4_RESIDENT_POOL_AGE) DS4_PC(p,consumed_late_older80,1);
    } else {
        DS4_PC(p,consumed_future,1);DS4_PC(p,consumed_future_age_sum,age);
        if (age>__atomic_load_n(&p->counters.consumed_future_age_max,__ATOMIC_RELAXED))
            __atomic_store_n(&p->counters.consumed_future_age_max,age,__ATOMIC_RELAXED);
        if (age>DS4_RESIDENT_POOL_AGE) DS4_PC(p,consumed_future_older80,1);
    }
    p->ready_count--;return 1;
}
/* Teardown only: the sole join happens before fd/model lifetime ends. */
static inline void ds4_pool_reset(ds4_resident_pool *p) {
    if (!p->initialized) return;
    DS4_PC(p,resets,1);
    if (p->worker) {
        pthread_mutex_lock(&p->mutex);p->stop=1;pthread_cond_signal(&p->cond);pthread_mutex_unlock(&p->mutex);
        (void)pthread_join(p->thread,NULL);DS4_PC(p,joins,1);p->worker=0;
        p->stack_bytes=0;p->guard_bytes=0;
    }
    if (p->job.bytes && ds4_pool_free(p,&p->job)) DS4_PC(p,reset_result_discards,1);
    for (uint32_t i=0;i<DS4_RESIDENT_POOL_LAYERS;i++) {
        if (p->ready[i].bytes && ds4_pool_free(p,&p->ready[i])) { p->ready_count--;DS4_PC(p,reset_ready_discards,1); }
        if (p->queue[i].valid) { p->queue[i].valid=0;p->queue_count--;DS4_PC(p,reset_queue_discards,1); }
    }
    if (p->synchronization) { pthread_cond_destroy(&p->cond);pthread_mutex_destroy(&p->mutex);p->synchronization=0; }
    p->stop=0;p->pending=0;p->job_fd=-1;p->model_map=NULL;p->model_size=0;p->generation=0;
    memset(p->latest_valid,0,sizeof(p->latest_valid));
    p->native_recheck=NULL;p->native_recheck_context=NULL;
    memset(&p->native_recheck_owner,0,sizeof(p->native_recheck_owner));
    __atomic_store_n(&p->state,DS4_POOL_IDLE,__ATOMIC_RELEASE);
}
#endif
