#ifndef DS4_RESIDENT_POOL_GATE_H
#define DS4_RESIDENT_POOL_GATE_H
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
/* Literal boolean only. Positive request additionally requires the existing
 * strict POOL1 gate; this parser never reads model/runtime metadata. */
static inline int ds4_resident_pool_native_recheck_parse(const char *text,int *out) {
    if (!out) return 0;
    if (!text || !*text || !strcmp(text,"0")) { *out=0;return 1; }
    if (strcmp(text,"1")) return 0;
    *out=1;return 1;
}
/* Pure strict decimal parser: no signs, whitespace, overflow or suffixes.
 * The payload clock starts at admission; queued requests keep their own80 TTL. */
static inline int ds4_resident_pool_ready_age_parse(const char *text,uint32_t *out) {
    if (!out) return 0;
    if (!text || !*text) { *out=80;return 1; }
    uint32_t value=0;
    for (const unsigned char *p=(const unsigned char *)text;*p;p++) {
        if (*p<'0' || *p>'9' || value>(1600u-(uint32_t)(*p-'0'))/10u) return 0;
        value=value*10u+(uint32_t)(*p-'0');
    }
    if (value<80 || value>1600) return 0;
    *out=value;return 1;
}
/* Return off0, compatible requested1, invalid-1. Pure model-free config gate;
 * exponent bits remain meaningful under production -ffast-math. */
static inline int ds4_resident_pool_gate(const char *pool,const char *gap,
        const char *backfill,const char *late,const char *subs,const char *mode,
        const char *policy,int ordinary,uint32_t layers,uint32_t used) {
    if (!pool || !*pool || !strcmp(pool,"0")) return 0;
    if (strcmp(pool,"1") || !ordinary || layers!=40 || used!=6 ||
        !gap || !*gap || !backfill || strcmp(backfill,"1") || !late || strcmp(late,"1") ||
        (subs && *subs && strcmp(subs,"1")) || (mode && *mode && strcmp(mode,"apply")) ||
        (policy && strcmp(policy,"replace"))) return -1;
    char *end=NULL;float value=strtof(gap,&end);uint32_t bits;
    memcpy(&bits,&value,sizeof(bits));
    return end==gap || *end || (bits&UINT32_C(0x7f800000))==UINT32_C(0x7f800000) ||
        value<=0.0f || value>1.0f ? -1 : 1;
}
#endif
