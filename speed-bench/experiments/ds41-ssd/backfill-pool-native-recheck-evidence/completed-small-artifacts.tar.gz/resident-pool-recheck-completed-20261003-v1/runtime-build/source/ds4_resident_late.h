#ifndef DS4_RESIDENT_LATE_H
#define DS4_RESIDENT_LATE_H
#include <stdint.h>
#include <string.h>

/* Stack-only owner transaction. Coefficients are copied/restored as uint32
 * bytes, never reconstructed from affinities or evaluated by fast-math. */
typedef struct {
    int32_t original_ids[6];
    uint32_t original_weight_bits[6];
    uint32_t original_expert, slot;
    int active;
} ds4_resident_late_transaction;

static inline int ds4_resident_late_capture(ds4_resident_late_transaction *t,
        const int32_t *ids, const void *weights, uint32_t used, uint32_t total) {
    if (!t) return 0;
    memset(t, 0, sizeof(*t));
    if (!ids || !weights || used != 6 || total < 7) return 0;
    for (uint32_t i = 0; i < used; i++) {
        if (ids[i] < 0 || (uint32_t)ids[i] >= total) return 0;
        for (uint32_t j = 0; j < i; j++) if (ids[i] == ids[j]) return 0;
    }
    memcpy(t->original_ids, ids, sizeof(t->original_ids));
    memcpy(t->original_weight_bits, weights, sizeof(t->original_weight_bits));
    return 1;
}

static inline int ds4_resident_late_activate(ds4_resident_late_transaction *t,
        const int32_t *final_ids, uint32_t original_expert, uint32_t total) {
    if (!t) return 0;
    t->active = 0;
    if (!final_ids) return 0;
    uint32_t changed = 0, slot = 0;
    for (uint32_t i = 0; i < 6; i++) {
        if (final_ids[i] < 0 || (uint32_t)final_ids[i] >= total) return 0;
        for (uint32_t j = 0; j < i; j++) if (final_ids[i] == final_ids[j]) return 0;
        if (final_ids[i] != t->original_ids[i]) { changed++; slot = i; }
    }
    if (changed != 1 || (uint32_t)t->original_ids[slot] != original_expert) return 0;
    for (uint32_t i = 0; i < 6; i++)
        if (final_ids[slot] == t->original_ids[i]) return 0;
    t->original_expert = original_expert; t->slot = slot; t->active = 1;
    return 1;
}

static inline int ds4_resident_late_union(const ds4_resident_late_transaction *t,
        const int32_t *final_ids, int32_t out[7]) {
    if (!t || !t->active || !final_ids || !out) return 0;
    memcpy(out, final_ids, 6 * sizeof(*out));
    out[6] = (int32_t)t->original_expert;
    return 1;
}

static inline int ds4_resident_late_victim_better(uint32_t hotness, uint64_t age,
        uint32_t best_hotness, uint64_t best_age) {
    return hotness < best_hotness || (hotness == best_hotness && age < best_age);
}
#endif
