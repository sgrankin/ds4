/* Real private-file reads and lifecycle tests; no model or Metal access. */
#include <assert.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdint.h>
#include <unistd.h>
static int test_hold, test_entered;
static void before_read(void *p) {
    (void)p;
    __atomic_store_n(&test_entered,1,__ATOMIC_RELEASE);
    while (__atomic_load_n(&test_hold,__ATOMIC_ACQUIRE)) {
        struct timespec nap={0,1000000};nanosleep(&nap,NULL);
    }
}
#define DS4_RESIDENT_POOL_TEST_BEFORE_READ before_read
#include "../ds4_resident_pool.h"
#include "../ds4_resident_pool_gate.h"
#define COUNT(p,n) __atomic_load_n(&(p)->counters.n,__ATOMIC_RELAXED)
static uint8_t source[512*1024];
static char fixture[256];
static int fixture_open(size_t bytes) {
    int fd=open(fixture,O_RDWR|O_CREAT|O_TRUNC,0600);assert(fd>=0);
    for (size_t i=0;i<sizeof(source);i++) source[i]=(uint8_t)(i*17+3);
    assert(write(fd,source,bytes)==(ssize_t)bytes);return fd;
}
static ds4_resident_stage_identity identity(uint32_t layer,uint32_t expert,size_t bytes) {
    assert(bytes%3==0);
    return (ds4_resident_stage_identity){.model_map=source,.model_size=sizeof(source),
        .layer=layer,.expert=expert,.generation=17,.quant_types={22,22,8},
        .offsets={0,bytes/3,2*(bytes/3)},.lengths={bytes/3,bytes/3,bytes/3}};
}
static void wait_entered(void) {
    for (int i=0;i<5000;i++) {
        if (__atomic_load_n(&test_entered,__ATOMIC_ACQUIRE)) return;
        struct timespec nap={0,1000000};nanosleep(&nap,NULL);
    } assert(!"reader failed to enter");
}
static void hold(void) { __atomic_store_n(&test_entered,0,__ATOMIC_RELEASE);__atomic_store_n(&test_hold,1,__ATOMIC_RELEASE); }
static void release_reader(void) { __atomic_store_n(&test_hold,0,__ATOMIC_RELEASE); }
static void finish(ds4_resident_pool *p) {
    for (int i=0;i<5000;i++) {
        int state=ds4_pool_state(p);
        if (state==DS4_POOL_READY || state==DS4_POOL_FAILED) { ds4_pool_poll(p);return; }
        struct timespec nap={0,1000000};nanosleep(&nap,NULL);
    } assert(!"reader failed to complete");
}
static void clean(ds4_resident_pool *p) {
    ds4_pool_reset(p);
    assert(!p->payload_live && !p->ready_count && !p->queue_count && !p->worker && !p->synchronization);
    for(uint32_t i=0;i<40;i++) assert(!p->latest_valid[i]);
    assert(ds4_pool_owned(p)==p->metadata_bytes && p->owned_peak<=p->limit);
    assert(COUNT(p,allocations)==COUNT(p,frees) && COUNT(p,allocated_bytes)==COUNT(p,freed_bytes));
    assert(COUNT(p,dup_opens)==COUNT(p,dup_closes) && !COUNT(p,free_failures));
}
static void consume(ds4_resident_pool *p,ds4_resident_stage_identity *id,int late) {
    uint8_t *dest[3];
    for (int i=0;i<3;i++) { dest[i]=malloc((size_t)id->lengths[i]);assert(dest[i]); }
    assert(ds4_pool_copy(p,id,dest,late));
    for (int i=0;i<3;i++) { assert(!memcmp(dest[i],source+id->offsets[i],(size_t)id->lengths[i]));free(dest[i]); }
}
static void gate_tests(void) {
    uint32_t age=999;
    assert(ds4_resident_pool_ready_age_parse(NULL,&age) && age==80);
    assert(ds4_resident_pool_ready_age_parse("",&age) && age==80);
    assert(ds4_resident_pool_ready_age_parse("80",&age) && age==80);
    assert(ds4_resident_pool_ready_age_parse("1600",&age) && age==1600);
    const char *badage[]={"0","79","1601","-80","+80"," 80","80 ","8e1","80x","nan","inf","4294967376","1844674407370955161600"};
    for (size_t i=0;i<sizeof(badage)/sizeof(*badage);i++) {
        age=999;assert(!ds4_resident_pool_ready_age_parse(badage[i],&age) && age==999);
    }
    assert(!ds4_resident_pool_ready_age_parse("80",NULL));
    assert(!ds4_resident_pool_gate(NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0));
    assert(!ds4_resident_pool_gate("0","nan","0","0","2","native","drop",0,0,0));
    assert(ds4_resident_pool_gate("1",".30","1","1",NULL,NULL,NULL,1,40,6)==1);
    const char *badgap[]={"nan","inf","-inf","1e100","0","-0","-.1","1.1",".3x",""};
    for (size_t i=0;i<sizeof(badgap)/sizeof(*badgap);i++)
        assert(ds4_resident_pool_gate("1",badgap[i],"1","1","1","apply","replace",1,40,6)==-1);
    assert(ds4_resident_pool_gate("2",".3","1","1",NULL,NULL,NULL,1,40,6)==-1);
    assert(ds4_resident_pool_gate("1",".3","1","1","2",NULL,NULL,1,40,6)==-1);
    assert(ds4_resident_pool_gate("1",".3","1","1",NULL,"noop",NULL,1,40,6)==-1);
    assert(ds4_resident_pool_gate("1",".3","1","1",NULL,NULL,"drop",1,40,6)==-1);
    assert(ds4_resident_pool_gate("1",".3","1","1",NULL,NULL,NULL,0,40,6)==-1);
    assert(ds4_resident_pool_gate("1",".3","1","1",NULL,NULL,NULL,1,39,6)==-1);
    assert(ds4_resident_pool_gate("1",".3","1","0",NULL,NULL,NULL,1,40,6)==-1);
}
static void ranges(void) {
    ds4_resident_pool p={0};uint64_t bytes;
    assert(!ds4_pool_init(&p,DS4_RESIDENT_POOL_LIMIT+1));
    assert(ds4_pool_init(&p,DS4_RESIDENT_POOL_LIMIT));
    ds4_resident_stage_identity id=identity(0,1,96),bad=id;
    assert(ds4_pool_valid(&id,&bytes) && bytes==96);
    bad.layer=40;assert(!ds4_pool_valid(&bad,&bytes));bad=id;bad.lengths[0]=0;assert(!ds4_pool_valid(&bad,&bytes));
    bad=id;bad.offsets[0]=UINT64_MAX;assert(!ds4_pool_valid(&bad,&bytes));
    bad=id;bad.model_size=UINT64_MAX;bad.offsets[0]=LLONG_MAX;assert(!ds4_pool_valid(&bad,&bytes));
    bad=id;bad.lengths[0]=17*1024*1024;bad.model_size=UINT64_MAX;assert(!ds4_pool_valid(&bad,&bytes));
    /* 40 retained payloads plus one outstanding result charged only once. */
    uint64_t q2=ds4_pool_round(9953280,p.page),stack=ds4_pool_round(DS4_RESIDENT_POOL_STACK,p.page);
    assert(41*q2+p.metadata_bytes+stack+p.page<DS4_RESIDENT_POOL_LIMIT);
    printf("budget: page=%llu metadata=%llu Q2_capacity=%llu 40READY+1READING+stack+guard=%llu cap=%llu\n",
        (unsigned long long)p.page,(unsigned long long)p.metadata_bytes,(unsigned long long)q2,
        (unsigned long long)(41*q2+p.metadata_bytes+stack+p.page),(unsigned long long)p.limit);
    clean(&p);
}
static void read_fd_and_replacement(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));int fd=fixture_open(sizeof(source));
    int flags=fcntl(fd,F_GETFL),fdflags=fcntl(fd,F_GETFD);
    ds4_resident_stage_identity a=identity(2,1,96),b=identity(2,2,96);
    hold();assert(ds4_pool_request(&p,fd,&a));wait_entered();
    assert(fcntl(p.job_fd,F_GETFD)&FD_CLOEXEC);
    assert(fcntl(fd,F_GETFL)==flags && fcntl(fd,F_GETFD)==fdflags);
    assert(ds4_pool_request(&p,fd,&b) && p.queue_count==1);
    assert(ds4_pool_request(&p,fd,&a) && !p.queue_count && COUNT(&p,queue_reading_drops)==1);
    release_reader();finish(&p);assert(ds4_pool_ready(&p,&a));
    ds4_resident_stage_identity wrong=a;
    wrong.quant_types[0]++;assert(!ds4_pool_ready(&p,&wrong));wrong=a;
    wrong.offsets[0]++;assert(!ds4_pool_ready(&p,&wrong));wrong=a;
    wrong.lengths[0]++;assert(!ds4_pool_ready(&p,&wrong));wrong=a;
    wrong.expert++;assert(!ds4_pool_ready(&p,&wrong));wrong=a;
    wrong.model_map=source+1;assert(!ds4_pool_ready(&p,&wrong));wrong=a;
    wrong.model_size--;assert(!ds4_pool_ready(&p,&wrong));
    assert(ds4_pool_ready(&p,&a) && p.ready_count==1);
    hold();assert(ds4_pool_request(&p,fd,&b));wait_entered();
    assert(ds4_pool_ready(&p,&a)); /* old READY survives replacement read */
    close(fd); /* admitted reader owns its CLOEXEC duplicate */
    release_reader();finish(&p);assert(!ds4_pool_ready(&p,&a) && ds4_pool_ready(&p,&b));
    assert(COUNT(&p,ready_replaced)==1);consume(&p,&b,1);
    assert(COUNT(&p,consumed_late)==1 && !COUNT(&p,consumed_future));
    clean(&p);
}
static void queues_and_no_hot_wait(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));int fd=fixture_open(sizeof(source));
    ds4_resident_stage_identity active=identity(0,1,96);
    hold();assert(ds4_pool_request(&p,fd,&active));wait_entered();
    for (uint32_t layer=0;layer<40;layer++) { ds4_resident_stage_identity q=identity(layer,10,96);assert(ds4_pool_request(&p,fd,&q)); }
    assert(p.queue_count==40 && p.queue_peak==40 && COUNT(&p,admissions)==1);
    ds4_resident_stage_identity recent=identity(10,12,96);
    assert(ds4_pool_request(&p,fd,&recent));assert(p.queue[10].id.expert==12 && COUNT(&p,queue_updates)==1);
    assert(ds4_pool_request(&p,fd,&recent));assert(COUNT(&p,dedup_queued)==1);
    ds4_resident_stage_identity stale=recent;stale.generation++;assert(!ds4_pool_request(&p,fd,&stale));
    assert(ds4_pool_request(&p,fd,&active));assert(p.queue_count==39 && COUNT(&p,queue_reading_drops)==1);
    release_reader();finish(&p);assert(ds4_pool_ready(&p,&active));
    uint64_t admitted=COUNT(&p,admissions); /* polling/peek must never queue-kick */
    for(int i=0;i<50;i++) { ds4_pool_poll(&p);assert(ds4_pool_ready(&p,&active)); }
    assert(COUNT(&p,admissions)==admitted);
    assert(!pthread_mutex_lock(&p.mutex));
    assert(!ds4_pool_kick(&p,10)); /* trylock returns immediately, no deadlock */
    assert(COUNT(&p,handoff_defers)==1);
    ds4_resident_stage_identity q0=identity(0,10,96);assert(ds4_pool_request(&p,fd,&q0));
    assert(ds4_pool_request(&p,fd,&active)); /* clears queued layer0 without hot wait */
    assert(COUNT(&p,queue_ready_drops)==1);
    assert(!pthread_mutex_unlock(&p.mutex));assert(ds4_pool_request(&p,fd,&active));
    finish(&p);assert(ds4_pool_ready(&p,&recent)==0); /* oldest layer1 won */
    ds4_resident_stage_identity one=identity(1,10,96);assert(ds4_pool_ready(&p,&one));
    hold();assert(ds4_pool_kick(&p,10));wait_entered();assert(p.job.id.expert==12);
    release_reader();finish(&p);assert(ds4_pool_ready(&p,&recent));consume(&p,&recent,0);
    clean(&p);close(fd);
}
static void expiry_and_fault(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));int fd=fixture_open(40);
    ds4_resident_stage_identity id=identity(2,1,96);
    assert(ds4_pool_request(&p,fd,&id));finish(&p);
    assert(COUNT(&p,failed)==1 && COUNT(&p,returned_bytes)==40 && COUNT(&p,pread_calls)==3);
    assert(!p.ready_count && !p.payload_live && ds4_pool_state(&p)==DS4_POOL_IDLE);clean(&p);close(fd);
    fd=fixture_open(sizeof(source));memset(&p,0,sizeof(p));assert(ds4_pool_init(&p,2*1024*1024));
    hold();assert(ds4_pool_request(&p,fd,&id));wait_entered();
    ds4_resident_stage_identity q=identity(3,1,96);assert(ds4_pool_request(&p,fd,&q));
    for(int i=0;i<81;i++) ds4_pool_tick(&p);
    assert(ds4_pool_state(&p)==DS4_POOL_READING && p.payload_live && !p.queue_count && COUNT(&p,queue_expired)==1);
    release_reader();finish(&p);assert(!p.ready_count && COUNT(&p,ready_expired)==1);
    assert(COUNT(&p,completion_harvest_expired)==1 && !COUNT(&p,stored_ready_expired));
    assert(ds4_pool_request(&p,fd,&id));finish(&p);assert(ds4_pool_ready(&p,&id));
    for(int i=0;i<80;i++) ds4_pool_tick(&p);assert(ds4_pool_ready(&p,&id));
    ds4_pool_tick(&p);assert(!ds4_pool_ready(&p,&id));
    assert(COUNT(&p,ready_expired)==2 && COUNT(&p,stored_ready_expired)==1);clean(&p);close(fd);
    memset(&p,0,sizeof(p));assert(ds4_pool_init(&p,2*1024*1024));
    assert(!ds4_pool_request(&p,-1,&id));assert(COUNT(&p,invalid_requests)==1);
    fd=fixture_open(sizeof(source));close(fd);
    assert(ds4_pool_request(&p,fd,&id));assert(COUNT(&p,dup_failures)==1 && !p.payload_live && p.queue_count==1);
    clean(&p);
}
static void longer_payload_age(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));
    assert(!ds4_pool_set_ready_age(&p,79) && !ds4_pool_set_ready_age(&p,1601));
    assert(ds4_pool_set_ready_age(&p,1600));int fd=fixture_open(sizeof(source));
    ds4_resident_stage_identity a=identity(2,1,96),q=identity(3,1,96),b=identity(2,2,96);
    hold();assert(ds4_pool_request(&p,fd,&a));wait_entered();
    assert(!ds4_pool_set_ready_age(&p,80)); /* cannot change active ownership */
    assert(ds4_pool_request(&p,fd,&q));
    for(int i=0;i<81;i++) ds4_pool_tick(&p);
    assert(COUNT(&p,queue_expired)==1 && !p.queue_count && ds4_pool_state(&p)==DS4_POOL_READING);
    release_reader();finish(&p);assert(ds4_pool_ready(&p,&a));
    assert(!COUNT(&p,ready_expired));
    for(int i=0;i<40;i++) ds4_pool_tick(&p);consume(&p,&a,0);
    assert(COUNT(&p,consumed_future_age_sum)==121 && COUNT(&p,consumed_future_age_max)==121 && COUNT(&p,consumed_future_older80)==1);
    assert(ds4_pool_request(&p,fd,&a));finish(&p);
    for(int i=0;i<1600;i++) ds4_pool_tick(&p);assert(ds4_pool_ready(&p,&a));
    consume(&p,&a,1);
    assert(COUNT(&p,consumed_late_age_sum)==1600 && COUNT(&p,consumed_late_age_max)==1600 && COUNT(&p,consumed_late_older80)==1);
    assert(ds4_pool_request(&p,fd,&a));finish(&p);
    for(int i=0;i<1601;i++) ds4_pool_tick(&p);assert(!ds4_pool_ready(&p,&a));
    assert(COUNT(&p,stored_ready_expired)==1 && COUNT(&p,ready_expired)==1 && !COUNT(&p,completion_harvest_expired));
    assert(ds4_pool_request(&p,fd,&a));finish(&p);
    for(int i=0;i<81;i++) ds4_pool_tick(&p);assert(ds4_pool_ready(&p,&a));
    assert(ds4_pool_request(&p,fd,&b));finish(&p);
    assert(!ds4_pool_ready(&p,&a) && ds4_pool_ready(&p,&b) && COUNT(&p,ready_replaced)==1);
    clean(&p);assert(ds4_pool_set_ready_age(&p,80) && p.ready_age==80);close(fd);
}
static void budget(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,1024*1024));int fd=fixture_open(sizeof(source));
    for(uint32_t layer=0;layer<3;layer++) { ds4_resident_stage_identity id=identity(layer,1,192*1024);assert(ds4_pool_request(&p,fd,&id));finish(&p); }
    assert(p.ready_count==3);
    ds4_resident_stage_identity blocked=identity(3,1,192*1024);
    assert(ds4_pool_request(&p,fd,&blocked));assert(p.queue_count==1 && ds4_pool_state(&p)==DS4_POOL_IDLE);
    assert(COUNT(&p,budget_defers)>0 && p.owned_peak<=p.limit);
    ds4_resident_stage_identity zero=identity(0,1,192*1024);consume(&p,&zero,0);
    assert(ds4_pool_kick(&p,3));finish(&p);assert(ds4_pool_ready(&p,&blocked));
    clean(&p);close(fd);
}
static void *unblock(void *unused) { (void)unused;struct timespec nap={0,20000000};nanosleep(&nap,NULL);release_reader();return NULL; }
static void reset_reading(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));int fd=fixture_open(sizeof(source));
    ds4_resident_stage_identity id=identity(2,1,96);
    hold();assert(ds4_pool_request(&p,fd,&id));wait_entered();
    ds4_resident_stage_identity q=identity(3,1,96);assert(ds4_pool_request(&p,fd,&q));
    close(fd);pthread_t helper;assert(!pthread_create(&helper,NULL,unblock,NULL));
    clean(&p);assert(!pthread_join(helper,NULL));
    assert(COUNT(&p,joins)==1 && COUNT(&p,reset_result_discards)==1 && COUNT(&p,reset_queue_discards)==1);
    fd=fixture_open(sizeof(source));id.generation++;assert(ds4_pool_request(&p,fd,&id));finish(&p);consume(&p,&id,0);
    clean(&p);assert(COUNT(&p,worker_starts)==2 && COUNT(&p,joins)==2);close(fd);
}
static void concurrent_handoffs(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));int fd=fixture_open(sizeof(source));
    for (uint32_t i=0;i<2000;i++) {
        ds4_resident_stage_identity id=identity(i%40,1+(i/40)%4,96);
        ds4_pool_tick(&p);assert(ds4_pool_request(&p,fd,&id));
        if (ds4_pool_ready(&p,&id)) consume(&p,&id,i&1);
        assert(p.queue_count<=40 && p.ready_count<=40 && ds4_pool_owned(&p)<=p.limit);
        if (i%11==0) { struct timespec nap={0,100000};nanosleep(&nap,NULL); }
    }
    clean(&p);close(fd);assert(COUNT(&p,admissions)>10 && COUNT(&p,worker_starts)==1);
}
static void latest_over_inflight(void) {
    ds4_resident_pool p={0};assert(ds4_pool_init(&p,2*1024*1024));int fd=fixture_open(sizeof(source));
    ds4_resident_stage_identity a=identity(2,1,96),b=identity(2,2,96);
    assert(ds4_pool_request(&p,fd,&a));finish(&p);assert(ds4_pool_ready(&p,&a));
    hold();assert(ds4_pool_request(&p,fd,&b));wait_entered();
    assert(ds4_pool_request(&p,fd,&a));assert(ds4_pool_ready(&p,&a));
    ds4_resident_stage_identity foreign=b;foreign.generation++;
    assert(!ds4_pool_request(&p,fd,&foreign));assert(ds4_pool_identity_equal(&p.latest[2],&a));
    foreign=b;foreign.lengths[0]=0;assert(!ds4_pool_request(&p,fd,&foreign));
    assert(ds4_pool_identity_equal(&p.latest[2],&a));
    release_reader();finish(&p);assert(ds4_pool_ready(&p,&a) && !ds4_pool_ready(&p,&b));
    assert(COUNT(&p,ready_superseded)==1 && !COUNT(&p,ready_replaced));
    /* Update latest even if the older result is already complete but has not
     * been harvested. Request-before-poll order must retain A in this case. */
    hold();assert(ds4_pool_request(&p,fd,&b));wait_entered();release_reader();
    for(int i=0;i<5000 && ds4_pool_state(&p)!=DS4_POOL_READY;i++) { struct timespec nap={0,1000000};nanosleep(&nap,NULL); }
    assert(ds4_pool_state(&p)==DS4_POOL_READY);
    assert(ds4_pool_request(&p,fd,&a));assert(ds4_pool_ready(&p,&a) && !ds4_pool_ready(&p,&b));
    assert(COUNT(&p,ready_superseded)==2 && COUNT(&p,ready_superseded_bytes)==192);
    /* An ABA request ending at the exact reading identity keeps it useful. */
    hold();assert(ds4_pool_request(&p,fd,&b));wait_entered();
    assert(ds4_pool_request(&p,fd,&a));assert(ds4_pool_request(&p,fd,&b));
    release_reader();finish(&p);assert(ds4_pool_ready(&p,&b) && !ds4_pool_ready(&p,&a));
    assert(COUNT(&p,ready_superseded)==2 && COUNT(&p,ready_replaced)==1);
    consume(&p,&b,0);clean(&p);close(fd);
}
int main(void) {
    snprintf(fixture,sizeof(fixture),"speed-bench/ideas/artifacts/resident-pool-cpu/fixture-%ld.bin",(long)getpid());
    gate_tests();ranges();read_fd_and_replacement();queues_and_no_hot_wait();expiry_and_fault();longer_payload_age();budget();reset_reading();concurrent_handoffs();latest_over_inflight();unlink(fixture);
    puts("PASS: strict opt-in gates; real short-read/EOF; CLOEXEC/descriptor policy and lifetime; one-worker latest40 queue; READY retention/expiry; nonwaiting handoff; bounded mapped allocation; busy reset/restart; balanced frees/fds");return 0;
}
