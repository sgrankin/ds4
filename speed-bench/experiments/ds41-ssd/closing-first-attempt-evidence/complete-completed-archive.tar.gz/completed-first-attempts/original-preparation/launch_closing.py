#!/usr/bin/env python3
"""Preflight only by default; execution requires a named ROOT model grant."""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
BUILD=Path('/Volumes/Models/ds4/.workspaces/idea-quant-closing/speed-bench/ideas/artifacts/closing-prepared-20261002-v1')
PLAN_SHA='cca9ffbc4e8f5d77c77f7b2c68f622dc144cbd54d426adc80b854418ba40ed65'
COMMAND_SHA='c4634fe3b5005492bf6d2b14193ee559ba20258332d334f717fb980246831998'
def sha(p):
    p=Path(p)
    if p.suffix.lower()=='.gguf':raise ValueError('No model hashing')
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def preflight():
    if sha(BUILD/'plan.json')!=PLAN_SHA or sha(BUILD/'prepared-command.json')!=COMMAND_SHA:raise ValueError('Frozen plan/command differs')
    plan=json.loads((BUILD/'plan.json').read_text());command=json.loads((BUILD/'prepared-command.json').read_text())
    expected=[plan['launch_python'],plan['guard'],plan['pressure'],'--',plan['launch_python'],str(BUILD/'run_closing.py'),str(BUILD/'plan.json'),PLAN_SHA]
    if command['argv']!=expected or command['cwd']!='/Volumes/Models/ds4' or command['environment']!=plan['environment']:raise ValueError('Exact prepared command required')
    for p,h in plan['asset_sha256'].items():
        if sha(p)!=h:raise ValueError('Frozen asset differs: '+p)
    identity=plan['guard_interpreter_identity']
    if sha(plan['guard'])!=plan['guard_sha256'] or sha(identity['path'])!=identity['sha256']:raise ValueError('Pinned guard/interpreter differs')
    return plan,command
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args()
    plan,command=preflight();print(json.dumps(dict(status='PREFLIGHT_PASS',assets=len(plan['asset_sha256']),model_access=False)),flush=True)
    if not a.execute:return 0
    env={k:v for k,v in os.environ.items() if not k.startswith('DS4')};env.update(command['environment'])
    return subprocess.run(command['argv'],cwd=command['cwd'],env=env).returncode
if __name__=='__main__':sys.exit(main())
