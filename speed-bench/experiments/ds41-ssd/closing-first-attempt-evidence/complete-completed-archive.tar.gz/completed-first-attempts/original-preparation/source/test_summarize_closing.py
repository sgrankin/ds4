import copy,importlib.util,json,math,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('closing',ROOT/'speed-bench/summarize_closing.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def dump(path,value):path.write_text(json.dumps(value)+'\n')
def lines(path,rows):path.write_text(''.join(json.dumps(x)+'\n' for x in rows))

class CheckedClosing(unittest.TestCase):
    def setUp(self):
        base=ROOT/'speed-bench/ideas/artifacts/closing-cpu-fixtures';base.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=base);self.out=Path(self.temp.name)
        self.fixture={'cases':[{'id':k,'answer':v,'prompt':'Question '+k} for k,v in c.GOLDS.items()]}
    def tearDown(self):self.temp.cleanup()
    def make(self,boost=0,pieces=None,cap=False):
        rows=[]
        for case in self.fixture['cases']:
            seq=pieces or [b'x',b'</think>',str(case['answer']).encode()]
            if cap:seq=[b'x']*2048
            trace=[];raw=bytearray();final=bytearray();closed=False;reason=0
            rng=20261002;actives=marker=active_marker=changes=0;masses=[];kls=[];dns=[]
            for i,piece in enumerate(seq+([] if cap else [b''])):
                stop=i==len(seq);inside=not closed;prior=reason
                token=1 if stop else c.TOKEN if piece==b'</think>' else 12
                active=boost>0 and inside and prior>=1024;delta=2 if active else 0
                t=dict(step=i,token_id=token,stop=stop,inside_thinking=inside,generated_thinking_tokens=prior,
                    policy_active=active,selected_marker=token==c.TOKEN,applied_logit_delta=delta,
                    rng_before=f'{rng:016x}',rng_after=f'{rng+1:016x}',piece_hex=piece.hex());rng+=1
                actives+=active;marker+=token==c.TOKEN and inside;active_marker+=token==c.TOKEN and active
                if i%32==0 and inside:
                    m=.0001;alpha=delta/c.TEMP;lz=math.log1p(m*math.expm1(alpha));kl=max(0,lz-alpha*m);dn=lz-alpha*(token==c.TOKEN)
                    t.update(raw_marker_mass_pre_filter=m,kl_raw_to_policy_pre_filter=kl,selected_delta_nll_pre_filter=dn,
                        raw_argmax=12,policy_argmax=12,marker_best_minus_other_logit=-5)
                    masses.append(m);kls.append(kl);dns.append(dn)
                trace.append(t)
                if stop:continue
                raw.extend(piece)
                if not closed:reason+=1
                if piece==b'</think>':closed=True;final.clear()
                elif closed:final.extend(piece)
            answer=bytes(final).decode();valid=closed and answer.isdecimal();correct=valid and answer==str(case['answer'])
            row=dict(case=case['id'],suite='counting',status='CORRECT' if correct else 'INCORRECT' if valid else 'INVALID',
                parse_ok=valid,parse_reason='none' if valid else 'unclosed_reasoning' if not closed else 'empty_final' if not answer else 'unsupported_final_format',
                scorer='strict-final-v2',parsed_answer=answer if valid else '',marker_profile='closing',mapped_markers=1,
                closing_boost=boost,policy_direction='ADD',closing_token_id=c.TOKEN,scope='think',engine_penalty=0,
                engine_marker_profile='hesitation',engine_overthink_after=0,think_level=25,seed=20261002,temperature=.6,top_p=.95,
                min_p=0,max_tokens=2048,cache_gib_requested=64.,closing_after=1024,case_offset=0,case_limit=4,
                generated_tokens=len(seq),reasoning_tokens=reason,think_closed=closed,stopped=not cap,cap_hit=cap,correct_exact=correct,
                prefill_seconds=0.,decode_seconds=0.,final=answer,expected=str(case['answer']),prompt=case['prompt'],raw_trace=case['id']+'.txt')
            row['diagnostics']=dict(temperature_float_value=c.TEMP,stride=32,sampling_steps=len(trace),active_steps=actives,
                thinking_marker_selections=marker,active_marker_selections=active_marker,pre_filter_samples=len(masses),sampled_argmax_changes=changes,
                raw_marker_mass_mean=sum(masses)/len(masses),raw_marker_mass_max=max(masses),policy_kl_mean_pre_filter=sum(kls)/len(kls),
                selected_delta_nll_sum_pre_filter=sum(dns),cpu_seconds=0.,token_trace=case['id']+'.jsonl')
            (self.out/row['raw_trace']).write_bytes(raw);lines(self.out/row['diagnostics']['token_trace'],trace);rows.append(row)
        lines(self.out/'results.jsonl',rows);return rows
    def check(self,boost=0,rc=0):return c.validate_arm(self.out,boost,self.fixture,rc)
    def bad_row(self,field,value):
        rows=self.make();rows[0][field]=value;lines(self.out/'results.jsonl',rows)
        with self.assertRaises((ValueError,KeyError,TypeError)):self.check()
    def bad_trace(self,field,value,index=0,boost=0,pieces=None):
        rows=self.make(boost,pieces);p=self.out/rows[0]['diagnostics']['token_trace'];ts=c.jsonl(p);ts[index][field]=value;lines(p,ts)
        with self.assertRaises((ValueError,KeyError,TypeError)):self.check(boost)
    def test_complete_four_native(self):
        self.make();r,rows,infos=self.check();self.assertEqual((r['correct'],r['completed_correct'],r['tokens']),(4,4,12));self.assertEqual(r['active_steps'],0)
    def test_candidate_before_gate_direct(self):self.make(2);self.assertEqual(self.check(2)[0]['active_steps'],0)
    def test_gate1023_1024_and_after_close(self):
        rows=self.make(2,[b'x']*1024+[b'</think>',b'123']);r,_,info=self.check(2)
        self.assertFalse(info[0]['trace'][1023]['policy_active']);self.assertTrue(info[0]['trace'][1024]['policy_active']);self.assertFalse(info[0]['trace'][1025]['policy_active'])
    def test_repeat_close_resets_final(self):self.make(0,[b'x',b'</think>',b'9',b'</think>',b'123']);r=self.check()[0];self.assertEqual(r['cases_status'][0]['final'],'123')
    def test_empty_after_second_close(self):self.make(0,[b'x',b'</think>',b'123',b'</think>']);self.assertEqual(self.check(rc=3)[0]['invalid'],4)
    def test_cap_invalid_and_rc3(self):self.make(cap=True);r=self.check(rc=3)[0];self.assertEqual((r['invalid'],r['cap_hits'],r['completed_correct']),(4,4,0))
    def test_wrong_rc_is_not_repaired(self):
        self.make(cap=True)
        with self.assertRaises(ValueError):self.check()
    def test_incorrect_preserved(self):self.make(0,[b'x',b'</think>',b'999']);self.assertEqual(self.check()[0]['incorrect'],4)
    def test_capped_correct_separate(self):
        rows=self.make(0,[b'x']*2046+[b'</think>',b'123']);
        for row in rows:
            p=self.out/row['diagnostics']['token_trace'];ts=c.jsonl(p)[:-1];lines(p,ts);row.update(stopped=False,cap_hit=True);row['diagnostics']['sampling_steps']-=1
        lines(self.out/'results.jsonl',rows);r=self.check()[0];self.assertEqual((r['correct'],r['completed_correct'],r['capped_correct']),(1,0,1))
    def test_duplicate_or_missing_cases(self):
        for mode in ['duplicate','missing']:
            rows=self.make();rows=rows[:-1] if mode=='missing' else rows[:3]+[rows[0]];lines(self.out/'results.jsonl',rows)
            with self.assertRaises(ValueError):self.check()
    def test_wrong_gold(self):self.bad_row('expected','999')
    def test_changed_prompt(self):self.bad_row('prompt','new')
    def test_wrong_direction(self):self.bad_row('policy_direction','SUBTRACT')
    def test_wrong_effort(self):self.bad_row('think_level',75)
    def test_bool_integer(self):self.bad_row('seed',True)
    def test_wrong_temperature(self):self.bad_row('temperature',1.)
    def test_truncated_results(self):
        self.make();p=self.out/'results.jsonl';p.write_bytes(p.read_bytes()[:-1])
        with self.assertRaises(ValueError):self.check()
    def test_truncated_token_trace(self):
        rows=self.make();p=self.out/rows[0]['diagnostics']['token_trace'];p.write_bytes(p.read_bytes()[:-1])
        with self.assertRaises(ValueError):self.check()
    def test_signed_int_and_argmax_types(self):
        for k,v in [('token_id',-1),('token_id',2147483648),('token_id',True),('raw_argmax',True),('policy_argmax','12'),('raw_argmax',129280),('generated_thinking_tokens',1)]:self.bad_trace(k,v)
    def test_wrong_rng(self):self.bad_trace('rng_before','0000000000000000')
    def test_wrong_closing_piece(self):self.bad_trace('piece_hex',b'wrong'.hex(),1)
    def test_wrong_activity(self):self.bad_trace('policy_active',True)
    def test_wrong_selected_marker(self):self.bad_trace('selected_marker',True)
    def test_wrong_inactive_delta(self):self.bad_trace('applied_logit_delta',2)
    def test_wrong_metric(self):self.bad_trace('kl_raw_to_policy_pre_filter',.1)
    def test_wrong_mass(self):self.bad_trace('raw_marker_mass_pre_filter',1.1)
    def test_nonfinite(self):self.bad_trace('marker_best_minus_other_logit',float('nan'))
    def test_native_reference_and_circular_only(self):
        rows=self.make();report,rows,infos=self.check();ref=self.out/'ref';ref.mkdir()
        for p in self.out.iterdir():
            if p.is_file():(ref/p.name).write_bytes(p.read_bytes())
        self.assertTrue(c.check_reference(self.out,rows,infos,ref));self.assertTrue(c.check_reference(self.out,rows,infos,ref,True))
        infos[0]['trace'][0]['rng_after']='0000000000000000'
        with self.assertRaises(ValueError):c.check_reference(self.out,rows,infos,ref)
    def test_forbidden_model_hash(self):
        with self.assertRaises(ValueError):c.digest('/nonexistent/model.gguf')

if __name__=='__main__':unittest.main()
