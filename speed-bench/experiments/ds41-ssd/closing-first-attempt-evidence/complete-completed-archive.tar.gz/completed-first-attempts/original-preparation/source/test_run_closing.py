import ast,importlib.util,json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'speed-bench'))
spec=importlib.util.spec_from_file_location('driver',ROOT/'speed-bench/run_closing.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
class Driver(unittest.TestCase):
    def setUp(self):
        p=ROOT/'speed-bench/ideas/artifacts/closing-driver-fixtures';p.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=p);self.base=Path(self.temp.name);self.calls=[]
        fixture=self.base/'fixture.json';fixture.write_text('{}')
        self.plan=dict(output=str(self.base/'run'),fixture=str(fixture),reference='old25',run_cwd='private',environment={'DS4_OVERTHINK_PENALTY':'0'},
            arms=[dict(name=x,boost=b,argv=['frozen-helper',x],results_dir='generated') for x,b in [('native-before',0),('closing-add2',2),('native-after',0)]] ,distribution='pre-filter')
        self.path=self.base/'plan.json';self.path.write_text(json.dumps(self.plan))
    def tearDown(self):self.temp.cleanup()
    def mocks(self,rcs):
        test=self
        class Proc:
            pid=123
            def __init__(self,argv,**kwargs):test.calls.append((argv,kwargs));self.rc=rcs[len(test.calls)-1]
            def wait(self):return self.rc
        return Proc
    def execute(self,rcs,guard=None):
        with patch.object(d,'sha',return_value='hash'),patch.object(d,'require_guard',side_effect=guard or [dict(guard=True)]*9),patch.object(d,'check_assets'),patch.object(d,'model_identity',return_value={'path':'opaque'}),patch.object(d.subprocess,'Popen',self.mocks(rcs)),patch.object(d.analysis,'validate_arm',return_value=({'invalid':1},[],[])),patch.object(d.analysis,'check_reference',return_value=True),patch.dict(os.environ,{'DS4XYZ':'bad','DS4_RESIDENT_EXPERT_GAP':'bad','OTHER':'keep'}):
            return d.run(self.path,'hash')
    def test_rc3_preserved_three_first_attempts(self):
        self.assertEqual(self.execute([3,3,3]),3);self.assertEqual(len(self.calls),3)
        self.assertEqual([x[0][1] for x in self.calls],['native-before','closing-add2','native-after'])
        for _,kw in self.calls:
            self.assertNotIn('DS4XYZ',kw['env']);self.assertNotIn('DS4_RESIDENT_EXPERT_GAP',kw['env']);self.assertEqual(kw['env']['DS4_OVERTHINK_PENALTY'],'0')
        for name in ['native-before','closing-add2','native-after']:self.assertEqual(json.loads((self.base/'run'/(name+'-process.json')).read_text())['returncode'],3)
    def test_infrastructure_failure_stops_and_retains(self):
        with self.assertRaises(RuntimeError):self.execute([1])
        self.assertEqual(len(self.calls),1);self.assertTrue((self.base/'run/first-failure.json').exists());self.assertFalse((self.base/'run/summary.json').exists())
    def test_guard_rejection_precedes_model_function(self):
        with patch.object(d,'sha',return_value='hash'),patch.object(d,'require_guard',side_effect=RuntimeError('unguarded')),patch.object(d,'model_identity') as model:
            with self.assertRaises(RuntimeError):d.run(self.path,'hash')
            model.assert_not_called()
    def test_missing_plan_hash_precedes_guard(self):
        with patch.object(d,'sha',return_value='other'),patch.object(d,'require_guard') as guard:
            with self.assertRaises(ValueError):d.run(self.path,'hash')
            guard.assert_not_called()
    def test_guard_function_matches_accepted_v3(self):
        p=Path('/Volumes/Models/ds4/.workspaces/idea-agent-resident3-live/speed-bench/ideas/artifacts/resident-agent-three-live-prepared-20261002-v3/run_resident_agent_live.py')
        def body(src):return next(ast.dump(n,include_attributes=False) for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='require_guard')
        self.assertEqual(body((ROOT/'speed-bench/run_closing.py').read_text()),body(p.read_text()))
    def test_launcher_default_never_executes_or_reads_model(self):
        source=(ROOT/'speed-bench/launch_closing_template.py').read_text();ns={'__name__':'test'};exec(compile(source,'launcher','exec'),ns)
        with patch.object(sys,'argv',['launcher']),patch.object(ns['subprocess'],'run') as run:
            ns['preflight']=lambda:({'asset_sha256':{}},{'argv':['opaque']})
            self.assertEqual(ns['main'](),0);run.assert_not_called()
    def test_launcher_execute_clears_all_ds4(self):
        ns={'__name__':'test'};exec(compile((ROOT/'speed-bench/launch_closing_template.py').read_text(),'launcher','exec'),ns)
        command={'argv':['guard','frozen'],'cwd':'MAIN','environment':{'DS4_ONE':'frozen'}};ns['preflight']=lambda:({'asset_sha256':{}},command)
        with patch.object(sys,'argv',['launcher','--execute']),patch.object(ns['subprocess'],'run') as run,patch.dict(os.environ,{'DS4XYZ':'bad','DS4_TWO':'bad'}):
            run.return_value.returncode=3;self.assertEqual(ns['main'](),3);kw=run.call_args.kwargs
            self.assertEqual(run.call_args.args[0],command['argv']);self.assertNotIn('DS4XYZ',kw['env']);self.assertNotIn('DS4_TWO',kw['env']);self.assertEqual(kw['env']['DS4_ONE'],'frozen')
    def test_no_cpu_preparation_model_metadata_calls(self):
        tree=ast.parse((ROOT/'speed-bench/prepare_closing.py').read_text());calls=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
        self.assertNotIn('stat',calls)
        receivers=[ast.unparse(n.func.value) for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='resolve']
        self.assertEqual(receivers,['Path(__file__)'])
if __name__=='__main__':unittest.main()
