#include "../ds4.h"
#include "../speed-bench/closing_policy.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct { float z[17]; int copy_count,set_count,sample_count; } mock_session;
static int copy(void *p,float *out,int n) { mock_session *s=p;s->copy_count++;memcpy(out,s->z,n*sizeof(*out));return n; }
static int set(void *p,const float *in,int n) { mock_session *s=p;s->set_count++;memcpy(s->z,in,n*sizeof(*in));return 0; }
static int sample(void *p,float t,int k,float tp,float m,uint64_t *rng) {
    mock_session *s=p;s->sample_count++;return ds4_sample_logits(s->z,17,t,k,tp,m,rng);
}
static void reference(const float *raw,const float *q,int n,double t,int selected,double *kl,double *dnll) {
    double mp=-INFINITY,mq=-INFINITY;
    for(int i=0;i<n;i++) { if(raw[i]/t>mp)mp=raw[i]/t;if(q[i]/t>mq)mq=q[i]/t; }
    double sp=0,sq=0;for(int i=0;i<n;i++){sp+=exp(raw[i]/t-mp);sq+=exp(q[i]/t-mq);}
    const double lp=mp+log(sp),lq=mq+log(sq);*kl=0;
    for(int i=0;i<n;i++){double p=exp(raw[i]/t-lp);*kl+=p*(((double)raw[i]-(double)q[i])/t+lq-lp);}
    *dnll=((double)raw[selected]-(double)q[selected])/t+lq-lp;
}
int main(void) {
    assert(closing_piece_valid(CLOSING_TOKEN_ID,"</think>",8));
    assert(!closing_piece_valid(CLOSING_TOKEN_ID-1,"</think>",8));
    assert(!closing_piece_valid(CLOSING_TOKEN_ID,"</think> ",9));
    assert(!closing_piece_valid(CLOSING_TOKEN_ID,"</thi",5));
    assert(!closing_piece_valid(CLOSING_TOKEN_ID,NULL,8));
    const int ids[]={CLOSING_TOKEN_ID};assert(overthink_is_marker(CLOSING_TOKEN_ID,ids,1));
    assert(!closing_active(2,1,1023));assert(closing_active(2,1,1024));
    assert(!closing_active(0,1,2048));assert(!closing_active(2,0,2048));
    mock_session s={0};float original[17],raw[17],policy[17];double delta;
    for(int i=0;i<17;i++)original[i]=s.z[i]=(float)(i-7)*.177f;
    closing_api api={&s,copy,set,sample};
    for(int mode=0;mode<4;mode++)for(int seed=1;seed<=1000;seed++) {
        memcpy(s.z,original,sizeof(original));s.copy_count=s.set_count=s.sample_count=0;
        const int active=mode==3;const float boost=mode==0?0:2;
        const int inside=mode!=1,count=mode==2?1023:1024;
        float expected[17];memcpy(expected,original,sizeof(expected));if(active)expected[3]+=2;
        uint64_t rng=seed,expected_rng=seed;
        const int token=closing_sample(api,17,3,boost,inside,count,raw,policy,.6f,0,.95f,0,&rng,&delta);
        const int expected_token=ds4_sample_logits(expected,17,.6f,0,.95f,0,&expected_rng);
        assert(token==expected_token && rng==expected_rng && s.sample_count==1);
        assert(s.copy_count==active && s.set_count==2*active);
        assert(!memcmp(s.z,original,sizeof(original)));
        assert(delta==(active?(double)expected[3]-(double)original[3]:0));
        if(active)for(int i=0;i<17;i++)if(i!=3)assert(!memcmp(policy+i,original+i,sizeof(float)));
    }
    memcpy(s.z,original,sizeof(original));s.z[3]=-1000;uint64_t rng=1;
    assert(closing_sample(api,17,3,2,1,1024,raw,policy,.6f,0,.95f,0,&rng,&delta)!=3);
    puts("map/gate/single-cell/restore/direct native sampler RNG parity:4000 cases PASS");
    const int n=129280,id=128822;float *p=malloc(n*sizeof(*p)),*q=malloc(n*sizeof(*q));assert(p&&q);
    for(int trial=0;trial<13;trial++) {
        for(int i=0;i<n;i++)p[i]=(float)((i*17)%107-70)*.55f;
        p[id]=(float[]){-60,-20,-3,0,8,20,35,1e8f,-1e8f,.0000001f,123.123f,-123.123f,33554436.f}[trial];
        assert(closing_adjust(p,q,n,id,2,&delta));
        const double t=(double).6f,m=overthink_marker_mass(p,n,&id,1,t);
        for(int j=0;j<2;j++){
            const int selected=j?id:17;double kl,dnll,rkl,rdnll;
            closing_metrics(m,delta,t,selected==id,&kl,&dnll);
            reference(p,q,n,t,selected,&rkl,&rdnll);
            assert(fabs(kl-rkl)<1e-8 && fabs(dnll-rdnll)<1e-8);
        }
        for(int i=0;i<n;i++)if(i!=id)assert(!memcmp(p+i,q+i,sizeof(float)));
    }
    p[id]=1e8f;assert(closing_adjust(p,q,n,id,2,&delta)&&delta==0);
    double kl,dnll;closing_metrics(.2,delta,(double).6f,1,&kl,&dnll);assert(kl==0&&dnll==0);
    free(p);free(q);puts("129280 full-vocabulary rounded-FP32 diagnostics at Tfloat0.6:26 controls PASS");
    return 0;
}
