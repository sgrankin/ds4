#!/usr/bin/env python3
"""Frozen closing-only first-attempt generation driver; requires MAIN guard."""
import argparse,errno,fcntl,hashlib,json,os,shlex,subprocess,sys
from pathlib import Path
import summarize_closing as analysis
ROOT=Path('/Volumes/Models/ds4')
def sha(path):
    p=Path(path)
    if p.suffix.lower()=='.gguf': raise ValueError('No model hashing')
    with p.open('rb') as s: return hashlib.file_digest(s,'sha256').hexdigest()

def put(path,value):
    with Path(path).open('x') as s: json.dump(value,s,indent=2); s.write('\n')

def check_assets(plan):
    for p,h in plan['asset_sha256'].items():
        if sha(p)!=h: raise ValueError('Frozen asset differs: '+p)

def require_guard(plan):
    if sha(plan['guard'])!=plan['guard_sha256']: raise ValueError('Guard changed')
    args=shlex.split(subprocess.check_output(['/bin/ps','-p',str(os.getppid()),'-o','command='],text=True,timeout=2).strip())
    # argv0 can be the macOS framework interpreter instead of its launch shim.
    expected_tail=[plan['guard'],plan['pressure'],'--',plan['launch_python'],
                   str(Path(__file__).resolve()),str(Path(plan['build_dir'])/'plan.json'),sha(Path(plan['build_dir'])/'plan.json')]
    if not args or args[1:]!=expected_tail: raise RuntimeError('Exact MAIN guard parent required')
    interpreter=plan['guard_interpreter_identity']
    try: same=os.path.samefile(args[0],interpreter['path'])
    except OSError: same=False
    if not same or sha(interpreter['path'])!=interpreter['sha256']:
        raise RuntimeError('Pinned MAIN guard framework interpreter required')
    with (ROOT/'speed-bench/ideas/artifacts/model-job.lock').open('a+') as f:
        try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as error:
            if error.errno not in (errno.EAGAIN,errno.EWOULDBLOCK): raise
            return dict(parent_argv=args,exact_suffix_argv=True,interpreter_samefile=True,
                        interpreter_sha256=interpreter['sha256'],guard_lock_held=True)
        fcntl.flock(f,fcntl.LOCK_UN)
    raise RuntimeError('MAIN model lock must be held')

def model_identity(plan):
    p=Path(plan['model']['path'])
    if p.resolve()!=p: raise ValueError('Model alias is forbidden')
    s=p.stat(); actual=dict(path=str(p),bytes=s.st_size,mtime_ns=s.st_mtime_ns)
    if actual!=plan['model']: raise ValueError('Q2 model identity changed')
    return actual

def run(plan_path,expected):
    if sha(plan_path)!=expected:raise ValueError('Plan changed')
    plan=json.loads(plan_path.read_text());proof=require_guard(plan);check_assets(plan)
    model=model_identity(plan)
    out=Path(plan['output']);out.mkdir(parents=True,exist_ok=False)
    put(out/'plan.json',plan);put(out/'parent-proof.json',proof);put(out/'model-identity.json',model)
    base={k:v for k,v in os.environ.items() if not k.startswith('DS4')};base.update(plan['environment'])
    fixture=json.loads(Path(plan['fixture']).read_text());reports=[]
    try:
        for arm in plan['arms']:
            require_guard(plan);check_assets(plan);model_identity(plan)
            put(out/(arm['name']+'-command.json'),dict(argv=arm['argv'],cwd=plan['run_cwd'],ds4_environment={k:v for k,v in base.items() if k.startswith('DS4')}))
            print(json.dumps(dict(event='arm_start',arm=arm['name'],boost=arm['boost'])),flush=True)
            with (out/(arm['name']+'-stdout.log')).open('x') as so,(out/(arm['name']+'-stderr.log')).open('x') as se:
                proc=subprocess.Popen(arm['argv'],cwd=plan['run_cwd'],env=base,stdout=so,stderr=se)
                put(out/(arm['name']+'-started.json'),dict(pid=proc.pid))
                rc=proc.wait()
            put(out/(arm['name']+'-process.json'),dict(returncode=rc))
            if rc not in (0,3):raise RuntimeError('Producer infrastructure error; retained first attempt')
            report,rows,infos=analysis.validate_arm(arm['results_dir'],arm['boost'],fixture,rc)
            report.update(arm=arm['name'],old25_reference_parity=analysis.check_reference(arm['results_dir'],rows,infos,plan['reference'],arm['boost']>0))
            put(out/(arm['name']+'-summary.json'),report);reports.append(report)
            print(json.dumps(report),flush=True)
        require_guard(plan);check_assets(plan);model_identity(plan)
        put(out/'summary.json',dict(status='COMPLETE',arms=reports,all_first_attempts_retained=True,
            distribution=plan['distribution'],timing='Diagnostic only; no speed or default promotion.',
            completed_correct_requires='CORRECT and !cap_hit and stopped and think_closed'))
        return 3 if any(r['invalid'] for r in reports) else 0
    except BaseException as error:
        put(out/'first-failure.json',dict(type=type(error).__name__,message=str(error),completed_arm_reports=reports));raise

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan',type=Path);p.add_argument('plan_sha256')
    a=p.parse_args();sys.exit(run(a.plan,a.plan_sha256))
